#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include<stdio.h>
#include <stdio.h> 
#include <assert.h>
#include <math.h>
#include <stdlib.h>

#define BOUND 2
int kappa;
	// inputs
	int inputs[] = {2,9,4,10,5,1,6,8,7,3};

	int errorCheck();
	void calculate_output(int);
	void calculate_outputm1(int);
	void calculate_outputm2(int);
	void calculate_outputm3(int);
	void calculate_outputm4(int);
	void calculate_outputm5(int);
	void calculate_outputm6(int);
	void calculate_outputm7(int);
	void calculate_outputm8(int);
	void calculate_outputm9(int);
	void calculate_outputm10(int);
	void calculate_outputm11(int);
	void calculate_outputm12(int);
	void calculate_outputm13(int);
	void calculate_outputm14(int);
	void calculate_outputm15(int);
	void calculate_outputm16(int);
	void calculate_outputm17(int);
	void calculate_outputm18(int);
	void calculate_outputm19(int);
	void calculate_outputm20(int);
	void calculate_outputm21(int);
	void calculate_outputm22(int);
	void calculate_outputm23(int);
	void calculate_outputm24(int);
	void calculate_outputm25(int);
	void calculate_outputm26(int);
	void calculate_outputm27(int);
	void calculate_outputm28(int);
	void calculate_outputm29(int);
	void calculate_outputm30(int);
	void calculate_outputm31(int);
	void calculate_outputm32(int);
	void calculate_outputm33(int);
	void calculate_outputm34(int);
	void calculate_outputm35(int);
	void calculate_outputm36(int);
	void calculate_outputm37(int);
	void calculate_outputm38(int);
	void calculate_outputm39(int);
	void calculate_outputm40(int);
	void calculate_outputm41(int);
	void calculate_outputm42(int);
	void calculate_outputm43(int);
	void calculate_outputm44(int);
	void calculate_outputm45(int);
	void calculate_outputm46(int);
	void calculate_outputm47(int);
	void calculate_outputm48(int);
	void calculate_outputm49(int);
	void calculate_outputm50(int);
	void calculate_outputm51(int);
	void calculate_outputm52(int);
	void calculate_outputm53(int);
	void calculate_outputm54(int);
	void calculate_outputm55(int);
	void calculate_outputm56(int);
	void calculate_outputm57(int);
	void calculate_outputm58(int);
	void calculate_outputm59(int);
	void calculate_outputm60(int);
	void calculate_outputm61(int);
	void calculate_outputm62(int);
	void calculate_outputm63(int);
	void calculate_outputm64(int);
	void calculate_outputm65(int);
	void calculate_outputm66(int);
	void calculate_outputm67(int);
	void calculate_outputm68(int);
	void calculate_outputm69(int);
	void calculate_outputm70(int);
	void calculate_outputm71(int);
	void calculate_outputm72(int);
	void calculate_outputm73(int);
	void calculate_outputm74(int);
	void calculate_outputm75(int);
	void calculate_outputm76(int);
	void calculate_outputm77(int);
	void calculate_outputm78(int);
	void calculate_outputm79(int);
	void calculate_outputm80(int);
	void calculate_outputm81(int);
	void calculate_outputm82(int);
	void calculate_outputm83(int);
	void calculate_outputm84(int);
	void calculate_outputm85(int);
	void calculate_outputm86(int);
	void calculate_outputm87(int);
	void calculate_outputm88(int);
	void calculate_outputm89(int);
	void calculate_outputm90(int);
	void calculate_outputm91(int);
	void calculate_outputm92(int);
	void calculate_outputm93(int);
	void calculate_outputm94(int);
	void calculate_outputm95(int);
	void calculate_outputm96(int);
	void calculate_outputm97(int);
	void calculate_outputm98(int);
	void calculate_outputm99(int);
	void calculate_outputm100(int);
	void calculate_outputm101(int);
	void calculate_outputm102(int);
	void calculate_outputm103(int);
	void calculate_outputm104(int);
	void calculate_outputm105(int);
	void calculate_outputm106(int);
	void calculate_outputm107(int);
	void calculate_outputm108(int);
	void calculate_outputm109(int);
	void calculate_outputm110(int);
	void calculate_outputm111(int);
	void calculate_outputm112(int);
	void calculate_outputm113(int);
	void calculate_outputm114(int);
	void calculate_outputm115(int);
	void calculate_outputm116(int);
	void calculate_outputm117(int);
	void calculate_outputm118(int);
	void calculate_outputm119(int);
	void calculate_outputm120(int);
	void calculate_outputm121(int);
	void calculate_outputm122(int);
	void calculate_outputm123(int);
	void calculate_outputm124(int);
	void calculate_outputm125(int);
	void calculate_outputm126(int);
	void calculate_outputm127(int);
	void calculate_outputm128(int);
	void calculate_outputm129(int);
	void calculate_outputm130(int);
	void calculate_outputm131(int);
	void calculate_outputm132(int);
	void calculate_outputm133(int);
	void calculate_outputm134(int);
	void calculate_outputm135(int);
	void calculate_outputm136(int);
	void calculate_outputm137(int);
	void calculate_outputm138(int);
	void calculate_outputm139(int);
	void calculate_outputm140(int);
	void calculate_outputm141(int);
	void calculate_outputm142(int);
	void calculate_outputm143(int);
	void calculate_outputm144(int);
	void calculate_outputm145(int);
	void calculate_outputm146(int);
	void calculate_outputm147(int);
	void calculate_outputm148(int);
	void calculate_outputm149(int);
	void calculate_outputm150(int);
	void calculate_outputm151(int);
	void calculate_outputm152(int);
	void calculate_outputm153(int);
	void calculate_outputm154(int);
	void calculate_outputm155(int);

	 int a631351130  = 33;
	 int a322697925  = 35;
	 int a914727600 = 2;
	 int cf = 1;
	 int a1178609647 = 12;
	 int a1014630870 = 9;
	 int a623007887 = 22;
	 int a1281480214  = 33;
	 int a458716067 = -99;
	 int a533054965 = -187;
	 int a635095050 = 4;
	 int a493087397 = 48;
	 int a1304128308 = 9;
	 int a61424176 = 7;
	 int a137310972 = -160;
	 int a297777914 = -1;
	 int a1350544514  = 33;
	 int a668543261 = -103;
	 int a881759693 = 9;
	 int a224147222 = 485;
	 int a1809397514  = 33;
	 int a363377125 = 6;
	 int a2086194771  = 32;
	 int a558123585 = 270;
	 int a387693620 = 11;
	 int a754697839 = 9;
	 int a1425079908 = 1;
	 int a702083417 = 10;
	 int a230802418  = 32;
	 int a631219524 = 13;
	 int a462100686 = 6;
	 int a1034097962  = 36;
	 int a470024258 = 8;
	 int a1524975081 = 8;
	 int a281306570 = 2;
	 int a306593017 = 90;
	 int a11629652  = 34;
	 int a542521680  = 34;
	 int a2062265878 = 114;
	 int a995729035 = 1;
	 int a240070971 = 0;
	 int a1287740622 = 0;
	 int a1647447633 = 1;
	 int a333446562 = 1;
	 int a1783572941 = 1;
	 int a1717797827 = 1;
	 int a130136624 = 0;
	 int a758764692 = 1;
	 int a2027636238 = 1;
	 int a815200306 = 1;
	 int a204693615 = 0;
	 int a1079276458 = 0;
	 int a116248116 = 1;
	 int a426209962 = 0;
	 int a2114497607 = 0;
	 int a1891042067 = 1;
	 int a498158367 = 0;
	 int a1449483205 = 0;
	 int a2070216165 = 0;
	 int a1958569006 = 0;
	 int a1471952247 = 2;
	 int a854970918 = 0;
	 int a1406068516 = 3;
	 int a1323714376 = 2;
	 int a188376983 = 2;
	 int a2061130608 = 2;
	 int a943871142 = 3;
	 int a521016673 = 1;
	 int a1513636275 = 0;
	 int a706425043 = 0;
	 int a1019899841 = 3;
	 int a774092986 = 2;


	int errorCheck() {
	    if(((a61424176 == 7 && a1178609647 == 10) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_0\n"); fflush(stderr); abort(); }
	    }
	    if(((((266 < a306593017) && (401 >= a306593017)) && a1524975081 == 11) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_1\n"); fflush(stderr); abort(); }
	    }
	    if(((a387693620 == 6 && a1524975081 == 12) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_2\n"); fflush(stderr); abort(); }
	    }
	    if(((a281306570 == 1 && a1178609647 == 14) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_3\n"); fflush(stderr); abort(); }
	    }
	    if(((a754697839 == 10 && a1524975081 == 10) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_4\n"); fflush(stderr); abort(); }
	    }
	    if(((a914727600 == 9 && a1524975081 == 9) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_5\n"); fflush(stderr); abort(); }
	    }
	    if(((a1014630870 == 15 && ((277 < a2062265878) && (375 >= a2062265878))) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_6\n"); fflush(stderr); abort(); }
	    }
	    if(((a1304128308 == 6 && a1178609647 == 7) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_7\n"); fflush(stderr); abort(); }
	    }
	    if(((((3 < a493087397) && (122 >= a493087397)) && a1178609647 == 13) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_8\n"); fflush(stderr); abort(); }
	    }
	    if(((a387693620 == 11 && a1524975081 == 12) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_9\n"); fflush(stderr); abort(); }
	    }
	    if(((a702083417 == 4 && a2062265878 <=  130) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_10\n"); fflush(stderr); abort(); }
	    }
	    if(((a61424176 == 10 && a1178609647 == 10) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_11\n"); fflush(stderr); abort(); }
	    }
	    if(((a754697839 == 15 && a1524975081 == 10) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_12\n"); fflush(stderr); abort(); }
	    }
	    if(((a1304128308 == 9 && a1524975081 == 13) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_13\n"); fflush(stderr); abort(); }
	    }
	    if(((a230802418 == 33 && a281306570 == 7) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_14\n"); fflush(stderr); abort(); }
	    }
	    if(((a1304128308 == 7 && a1524975081 == 13) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_15\n"); fflush(stderr); abort(); }
	    }
	    if(((a387693620 == 7 && a1524975081 == 12) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_16\n"); fflush(stderr); abort(); }
	    }
	    if(((a914727600 == 8 && a1178609647 == 9) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_17\n"); fflush(stderr); abort(); }
	    }
	    if(((a1014630870 == 9 && ((277 < a2062265878) && (375 >= a2062265878))) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_18\n"); fflush(stderr); abort(); }
	    }
	    if(((a462100686 == 8 && a281306570 == 4) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_19\n"); fflush(stderr); abort(); }
	    }
	    if(((a914727600 == 6 && a1524975081 == 7) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_20\n"); fflush(stderr); abort(); }
	    }
	    if(((a631219524 == 16 && 375 < a2062265878) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_21\n"); fflush(stderr); abort(); }
	    }
	    if(((a881759693 == 12 && a281306570 == 8) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_22\n"); fflush(stderr); abort(); }
	    }
	    if(((a230802418 == 35 && a281306570 == 7) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_23\n"); fflush(stderr); abort(); }
	    }
	    if(((a1014630870 == 12 && ((277 < a2062265878) && (375 >= a2062265878))) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_24\n"); fflush(stderr); abort(); }
	    }
	    if(((a224147222 <=  193 && a1524975081 == 8) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_25\n"); fflush(stderr); abort(); }
	    }
	    if(((a61424176 == 8 && a1178609647 == 10) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_26\n"); fflush(stderr); abort(); }
	    }
	    if(((306 < a493087397 && a281306570 == 6) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_27\n"); fflush(stderr); abort(); }
	    }
	    if(((a61424176 == 13 && a1178609647 == 10) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_28\n"); fflush(stderr); abort(); }
	    }
	    if(((a914727600 == 4 && a1178609647 == 9) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_29\n"); fflush(stderr); abort(); }
	    }
	    if(((((83 < a623007887) && (160 >= a623007887)) && a1178609647 == 8) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_30\n"); fflush(stderr); abort(); }
	    }
	    if(((306 < a493087397 && a1178609647 == 13) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_31\n"); fflush(stderr); abort(); }
	    }
	    if(((a11629652 == 35 && a1178609647 == 11) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_32\n"); fflush(stderr); abort(); }
	    }
	    if(((a1034097962 == 33 && a281306570 == 5) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_33\n"); fflush(stderr); abort(); }
	    }
	    if(((a702083417 == 10 && a2062265878 <=  130) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_34\n"); fflush(stderr); abort(); }
	    }
	    if(((a702083417 == 8 && a2062265878 <=  130) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_35\n"); fflush(stderr); abort(); }
	    }
	    if(((a281306570 == 5 && a1178609647 == 14) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_36\n"); fflush(stderr); abort(); }
	    }
	    if(((a2086194771 == 33 && a1524975081 == 14) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_37\n"); fflush(stderr); abort(); }
	    }
	    if(((a881759693 == 13 && a281306570 == 8) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_38\n"); fflush(stderr); abort(); }
	    }
	    if(((a1304128308 == 12 && a1524975081 == 13) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_39\n"); fflush(stderr); abort(); }
	    }
	    if(((a1014630870 == 14 && ((277 < a2062265878) && (375 >= a2062265878))) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_40\n"); fflush(stderr); abort(); }
	    }
	    if(((a881759693 == 6 && a281306570 == 8) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_41\n"); fflush(stderr); abort(); }
	    }
	    if(((a1304128308 == 11 && a1178609647 == 7) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_42\n"); fflush(stderr); abort(); }
	    }
	    if(((((42 < a623007887) && (83 >= a623007887)) && a1178609647 == 8) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_43\n"); fflush(stderr); abort(); }
	    }
	    if(((a754697839 == 8 && a1524975081 == 10) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_44\n"); fflush(stderr); abort(); }
	    }
	    if(((a702083417 == 6 && a2062265878 <=  130) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_45\n"); fflush(stderr); abort(); }
	    }
	    if(((a306593017 <=  109 && a1524975081 == 11) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_46\n"); fflush(stderr); abort(); }
	    }
	    if(((a61424176 == 9 && a1178609647 == 10) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_47\n"); fflush(stderr); abort(); }
	    }
	    if(((((351 < a224147222) && (472 >= a224147222)) && a1524975081 == 8) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_48\n"); fflush(stderr); abort(); }
	    }
	    if(((a914727600 == 2 && a1524975081 == 9) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_49\n"); fflush(stderr); abort(); }
	    }
	    if(((a322697925 == 36 && ((130 < a2062265878) && (277 >= a2062265878))) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_50\n"); fflush(stderr); abort(); }
	    }
	    if(((a702083417 == 9 && a2062265878 <=  130) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_51\n"); fflush(stderr); abort(); }
	    }
	    if(((a11629652 == 36 && a1178609647 == 11) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_52\n"); fflush(stderr); abort(); }
	    }
	    if(((a754697839 == 9 && a1524975081 == 10) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_53\n"); fflush(stderr); abort(); }
	    }
	    if(((a1014630870 == 13 && ((277 < a2062265878) && (375 >= a2062265878))) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_54\n"); fflush(stderr); abort(); }
	    }
	    if(((a230802418 == 36 && a281306570 == 7) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_55\n"); fflush(stderr); abort(); }
	    }
	    if(((((122 < a493087397) && (306 >= a493087397)) && a1178609647 == 13) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_56\n"); fflush(stderr); abort(); }
	    }
	    if(((a914727600 == 7 && a1524975081 == 9) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_57\n"); fflush(stderr); abort(); }
	    }
	    if(((a631219524 == 15 && 375 < a2062265878) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_58\n"); fflush(stderr); abort(); }
	    }
	    if(((a702083417 == 7 && a2062265878 <=  130) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_59\n"); fflush(stderr); abort(); }
	    }
	    if(((((122 < a493087397) && (306 >= a493087397)) && a281306570 == 6) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_60\n"); fflush(stderr); abort(); }
	    }
	    if(((a914727600 == 4 && a1524975081 == 9) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_61\n"); fflush(stderr); abort(); }
	    }
	    if(((a631219524 == 13 && 375 < a2062265878) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_62\n"); fflush(stderr); abort(); }
	    }
	    if(((((122 < a493087397) && (306 >= a493087397)) && a281306570 == 1) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_63\n"); fflush(stderr); abort(); }
	    }
	    if(((a1304128308 == 13 && a1178609647 == 7) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_64\n"); fflush(stderr); abort(); }
	    }
	    if(((a1034097962 == 35 && a281306570 == 5) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_65\n"); fflush(stderr); abort(); }
	    }
	    if(((a1034097962 == 36 && a281306570 == 5) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_66\n"); fflush(stderr); abort(); }
	    }
	    if(((a631219524 == 9 && 375 < a2062265878) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_67\n"); fflush(stderr); abort(); }
	    }
	    if(((a914727600 == 7 && a1524975081 == 7) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_68\n"); fflush(stderr); abort(); }
	    }
	    if(((a322697925 == 34 && ((130 < a2062265878) && (277 >= a2062265878))) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_69\n"); fflush(stderr); abort(); }
	    }
	    if(((a462100686 == 10 && a281306570 == 4) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_70\n"); fflush(stderr); abort(); }
	    }
	    if(((((109 < a306593017) && (266 >= a306593017)) && a1524975081 == 11) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_71\n"); fflush(stderr); abort(); }
	    }
	    if(((a2086194771 == 34 && a1524975081 == 14) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_72\n"); fflush(stderr); abort(); }
	    }
	    if(((a914727600 == 5 && a1524975081 == 7) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_73\n"); fflush(stderr); abort(); }
	    }
	    if(((401 < a306593017 && a1524975081 == 11) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_74\n"); fflush(stderr); abort(); }
	    }
	    if(((a61424176 == 11 && a1178609647 == 10) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_75\n"); fflush(stderr); abort(); }
	    }
	    if(((a230802418 == 34 && a281306570 == 7) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_76\n"); fflush(stderr); abort(); }
	    }
	    if(((((193 < a224147222) && (351 >= a224147222)) && a1524975081 == 8) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_77\n"); fflush(stderr); abort(); }
	    }
	    if(((a322697925 == 33 && ((130 < a2062265878) && (277 >= a2062265878))) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_78\n"); fflush(stderr); abort(); }
	    }
	    if(((a914727600 == 5 && a1178609647 == 9) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_79\n"); fflush(stderr); abort(); }
	    }
	    if(((a1304128308 == 6 && a1524975081 == 13) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_80\n"); fflush(stderr); abort(); }
	    }
	    if(((a1034097962 == 34 && a281306570 == 5) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_81\n"); fflush(stderr); abort(); }
	    }
	    if(((160 < a623007887 && a1178609647 == 8) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_82\n"); fflush(stderr); abort(); }
	    }
	    if(((a281306570 == 2 && a1178609647 == 14) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_83\n"); fflush(stderr); abort(); }
	    }
	    if(((a754697839 == 13 && a1524975081 == 10) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_84\n"); fflush(stderr); abort(); }
	    }
	    if(((a914727600 == 7 && a1178609647 == 9) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_85\n"); fflush(stderr); abort(); }
	    }
	    if(((a11629652 == 34 && a1178609647 == 11) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_86\n"); fflush(stderr); abort(); }
	    }
	    if(((a11629652 == 32 && a1178609647 == 11) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_87\n"); fflush(stderr); abort(); }
	    }
	    if(((((193 < a224147222) && (351 >= a224147222)) && a281306570 == 2) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_88\n"); fflush(stderr); abort(); }
	    }
	    if(((a631219524 == 10 && 375 < a2062265878) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_89\n"); fflush(stderr); abort(); }
	    }
	    if(((a914727600 == 3 && a1524975081 == 7) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_90\n"); fflush(stderr); abort(); }
	    }
	    if(((a281306570 == 3 && a1178609647 == 14) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_91\n"); fflush(stderr); abort(); }
	    }
	    if(((((351 < a224147222) && (472 >= a224147222)) && a281306570 == 2) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_92\n"); fflush(stderr); abort(); }
	    }
	    if(((a631219524 == 11 && 375 < a2062265878) && ((77 < a558123585) && (259 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_93\n"); fflush(stderr); abort(); }
	    }
	    if(((a1034097962 == 32 && a281306570 == 5) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_94\n"); fflush(stderr); abort(); }
	    }
	    if(((a881759693 == 10 && a281306570 == 8) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_95\n"); fflush(stderr); abort(); }
	    }
	    if(((a914727600 == 9 && a1524975081 == 7) && ((12 < a558123585) && (77 >= a558123585)))){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_96\n"); fflush(stderr); abort(); }
	    }
	    if(((a462100686 == 11 && a281306570 == 4) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_97\n"); fflush(stderr); abort(); }
	    }
	    if(((a230802418 == 32 && a281306570 == 7) && a558123585 <=  12)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_98\n"); fflush(stderr); abort(); }
	    }
	    if(((158 < a137310972 && a1178609647 == 12) && 259 < a558123585)){
	    cf = 0;
	    { fprintf(stderr, "REACHED_error_99\n"); fflush(stderr); abort(); }
	    }
	}
 void calculate_outputm29(int input) {
    if(((a470024258 == 8 && ((input == 5) &&  cf==1 )) && (((a635095050 == 4 && (a363377125 == 6 && a631351130 == 33)) && a1350544514 == 33) && a668543261 <=  -85))) {
    	cf = 0;
    	a1178609647 = ((a470024258 - a363377125) + 12);
    	a281306570 = ((a1178609647 * a363377125) + -76);
    	a558123585 = ((((((a558123585 * a668543261) % 14999) - 14155) % 14870) - -15129) * 1); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if((((a1809397514 == 33 && (( cf==1  && (input == 6)) && a1350544514 == 33)) && a1425079908 == 1) && (a635095050 == 4 && (a1281480214 == 33 && a668543261 <=  -85)))) {
    	
    	if((a1287740622 - 20) < a1287740622)
    	{
    	a1287740622 -= 2;
    	}
    	else
    	{
    	a1287740622 -= 0;
    	}
    	
    	
    	if((a1958569006 + 20) > a1958569006)
    	{
    	a1958569006 += 3;
    	}
    	else
    	{
    	a1958569006 += 0;
    	}
    	
    	cf = 0;
    	a493087397 = (((((a493087397 * a297777914) % 14999) - 14999) / 5) - 21784);
    	a281306570 = (a635095050 - -2); 
    	 printf("");//printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm1(int input) {
    if(((a1281480214 == 33 && ((( cf==1  && ((3 < a493087397) && (122 >= a493087397))) && a533054965 <=  -173) && a635095050 == 4)) && (a470024258 == 8 && (a363377125 == 6 && a631351130 == 33)))) {
    	calculate_outputm29(input);
    } 
}
 void calculate_outputm33(int input) {
    if((((input == 3) &&  cf==1 ) && (((a1281480214 == 33 && (a631351130 == 33 && (a668543261 <=  -85 && a470024258 == 8))) && a533054965 <=  -173) && a458716067 <=  -81))) {
    	cf = 0;
    	a1350544514 = 32 ;
    	a668543261 = (((((((a668543261 * a224147222) % 14999) - 13339) % 96) - -49) - -11862) - 11809);
    	a1524975081 = (a281306570 - -10);
    	a470024258 = ((a1524975081 * a363377125) + -63);
    	a1809397514 = 32 ;
    	a1281480214 = 32 ;
    	a297777914 = ((((((a297777914 * a224147222) % 14999) % 71) - -82) * 1) + -1);
    	a1425079908 = ((a363377125 * a363377125) + -34);
    	a387693620 = ((a363377125 - a363377125) + 12);
    	a533054965 = ((((((a533054965 * a224147222) % 14999) + 1470) % 49) - 122) + -1);
    	a631351130 = 32 ;
    	a558123585 = (((((((a558123585 * a224147222) % 14999) * 2) / 5) / 5) % 32) + 45);
    	a458716067 = (((((((a458716067 * a533054965) % 14999) / 5) + 26285) + -4752) % 38) - 56);
    	a363377125 = (a635095050 + 2); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if((a470024258 == 8 && (((((a533054965 <=  -173 && ((input == 6) &&  cf==1 )) && a363377125 == 6) && a1809397514 == 33) && a1281480214 == 33) && a631351130 == 33))) {
    	
        if((a1323714376 - 20) < a1323714376)
        {
        a1323714376 -= 1;
        }
        else
        {
        a1323714376 -= 0;
        }	

    	cf = 0;
    	a1304128308 = ((a1425079908 / a281306570) - -7);
    	a631351130 = 32 ;
    	a533054965 = ((((((((a533054965 * a224147222) % 14999) % 49) - 121) - 3) * 5) % 49) - 121);
    	a470024258 = (a1425079908 - -8);
    	a1281480214 = 32 ;
    	a1524975081 = (a363377125 + 7);
    	a1809397514 = 32 ;
    	a363377125 = (a1425079908 + 6);
    	a558123585 = (((((((a558123585 * a668543261) % 14999) % 32) - -45) - -14573) / 5) + -2877);
    	a458716067 = (((((((a458716067 * a668543261) % 14999) % 38) + -65) - 2) * 10) / 9);
    	a1425079908 = ((a470024258 + a470024258) + -16);
    	a668543261 = (((((((a668543261 * a297777914) % 14999) - 8767) % 96) - -11) - 7165) + 7165); 
    	 printf("");//printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm2(int input) {
    if(((a1809397514 == 33 && (((( cf==1  && 472 < a224147222) && a470024258 == 8) && a297777914 <=  10) && a458716067 <=  -81)) && (a1281480214 == 33 && a533054965 <=  -173))) {
    	calculate_outputm33(input);
    } 
}
 void calculate_outputm34(int input) {
    if(((((a631351130 == 33 && a1425079908 == 1) && a1350544514 == 33) && a533054965 <=  -173) && (a635095050 == 4 && (((input == 5) &&  cf==1 ) && a458716067 <=  -81)))) {
    	cf = 0;
    	a914727600 = ((a363377125 / a281306570) - -1);
    	a1178609647 = (a470024258 - -1);
    	a558123585 = (((((a558123585 * a458716067) % 14999) / 5) / 5) + 17827);
    	a458716067 = ((((((((a458716067 * a668543261) % 14999) + 5140) % 99) - 1) * 5) % 99) + 98); 
    	 printf("");//printf("%d\n", 24); fflush(stdout); 
    } if((((a297777914 <=  10 && (a533054965 <=  -173 && a668543261 <=  -85)) && ((a1281480214 == 33 && (( cf==1  && (input == 3)) && a1425079908 == 1)) && a363377125 == 6)) && a1891042067 == 10)) {
    	cf = 0;
    	a1014630870 = ((a635095050 + a363377125) + 5);
    	a2062265878 = (((((((a558123585 * a558123585) % 14999) * 2) - 0) - 0) % 48) - -326);
    	a558123585 = ((((((((a558123585 * a458716067) % 14999) * 2) % 90) - -167) * 5) % 90) - -86); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if(((a297777914 <=  10 && (((a1809397514 == 33 && ((input == 2) &&  cf==1 )) && a458716067 <=  -81) && a631351130 == 33)) && (a363377125 == 6 && a1281480214 == 33))) {
    	cf = 0;
    	a1350544514 = 34 ;
    	a1014630870 = ((a363377125 + a281306570) - -4);
    	a2062265878 = ((((((a533054965 * a668543261) % 14999) - -6674) - -4204) % 48) - -301);
    	a668543261 = (((((((a2062265878 * a458716067) % 14999) % 15) + 124) - -5826) / 5) + -1068);
    	a1425079908 = ((a635095050 / a1014630870) - -3);
    	a297777914 = (((((((a297777914 * a2062265878) % 14999) + 1602) - -755) - 6801) % 109) - -263);
    	a533054965 = ((((((a458716067 * a668543261) % 14999) % 101) + 29) + 1) / 5);
    	a558123585 = (((((((a558123585 * a458716067) % 14999) - 2567) + -3285) - 7978) % 90) - -168);
    	a631351130 = 34 ;
    	a1809397514 = 34 ;
    	a363377125 = (a1014630870 - 5);
    	a470024258 = (a1014630870 + -3);
    	a1281480214 = 34 ;
    	a458716067 = ((((((a458716067 * a668543261) % 14999) % 99) + 98) - 1) + 1); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm3(int input) {
    if(((a458716067 <=  -81 && a297777914 <=  10) && (((a668543261 <=  -85 && ((a542521680 == 32 &&  cf==1 ) && a470024258 == 8)) && a635095050 == 4) && a363377125 == 6))) {
    	calculate_outputm34(input);
    } 
}
 void calculate_outputm38(int input) {
    if(((( cf==1  && (input == 1)) && a631351130 == 33) && (a458716067 <=  -81 && ((a1350544514 == 33 && (a470024258 == 8 && a1281480214 == 33)) && a635095050 == 4)))) {
    	cf = 0;
    	a458716067 = ((((((a668543261 * a668543261) % 14999) % 38) + -64) + -16479) - -16471);
    	a558123585 = ((((((((a558123585 * a668543261) % 14999) % 32) - -45) - 8943) * 3) % 32) + 75);
    	a387693620 = (a363377125 + a363377125);
    	a297777914 = (((((((a458716067 * a668543261) % 14999) + 10665) - -3547) - -248) % 71) - -46);
    	a470024258 = ((a462100686 + a462100686) - 15);
    	a1524975081 = a387693620;
    	a1809397514 = 32 ;
    	a533054965 = (((((((a533054965 * a297777914) % 14999) + -14549) / 5) + 10718) % 49) - 136);
    	a1425079908 = (a1524975081 - 10);
    	a1350544514 = 32 ;
    	a363377125 = ((a387693620 + a281306570) + -9);
    	a635095050 = (a470024258 - 4);
    	a631351130 = 32 ;
    	a1281480214 = 32 ;
    	a668543261 = ((((((a668543261 * a297777914) % 14999) % 96) + 11) - -1) - -1); 
    	 printf("");//printf("%d\n", 25); fflush(stdout); 
    } if(((a1809397514 == 33 && (a297777914 <=  10 && ((a668543261 <=  -85 && a533054965 <=  -173) && a1350544514 == 33))) && (a458716067 <=  -81 && ( cf==1  && (input == 2))))) {
    	cf = 0;
    	a224147222 = (((((a533054965 * a458716067) % 14999) + 5666) - 18218) + 23436);
    	a281306570 = ((a470024258 * a470024258) + -62);
    	a635095050 = (a281306570 - -3); 
    	 printf("");//printf("%d\n", 26); fflush(stdout); 
    } if((((( cf==1  && (input == 3)) && a458716067 <=  -81) && a363377125 == 6) && (a470024258 == 8 && (a631351130 == 33 && (a297777914 <=  10 && a668543261 <=  -85))))) {
    	cf = 0;
    	a1178609647 = ((a363377125 * a635095050) + -11);
    	a558123585 = ((((((a558123585 * a297777914) % 14999) / 5) - 3690) * -4) / 10);
    	a493087397 = ((((((a558123585 * a297777914) % 14999) * 2) % 14846) + 15152) - -1); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm39(int input) {
    if(((a297777914 <=  10 && a363377125 == 6) && (a631351130 == 33 && (a470024258 == 8 && ((a635095050 == 4 && ( cf==1  && (input == 3))) && a533054965 <=  -173))))) {
    	cf = 0;
    	a533054965 = (((79 + -3922) - -3696) + -22);
    	a1350544514 = 32 ;
    	a558123585 = ((((((a558123585 * a668543261) % 14999) + 6381) % 32) + 44) + 0);
    	a754697839 = ((a462100686 * a470024258) + -90);
    	a668543261 = ((((((a558123585 * a533054965) % 96) + 91) / 5) - 22860) + 22840);
    	a635095050 = ((a281306570 - a754697839) - -15);
    	a1281480214 = 32 ;
    	a458716067 = ((((((a458716067 * a297777914) % 14999) + 8952) % 38) - 41) - 1);
    	a1524975081 = (a1425079908 + 9);
    	a297777914 = (((((a668543261 * a668543261) + 2370) % 71) + 82) + -1);
    	a470024258 = ((a363377125 - a363377125) + 9);
    	a1425079908 = (a754697839 - 12);
    	a1809397514 = 32 ;
    	a363377125 = 7; 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } if(((((a1425079908 == 1 && ( cf==1  && (input == 10))) && a458716067 <=  -81) && a1350544514 == 33) && ((a1281480214 == 33 && a297777914 <=  10) && a1809397514 == 33))) {
    	
    	
    	        if((a2070216165 + 20) > a2070216165)
        {
        a2070216165 +=  4;
        }
        else
        {
        a2070216165 +=  0;
        }	
        
        
    	cf = 0;
    	a1809397514 = 32 ;
    	a1350544514 = 32 ;
    	a533054965 = ((((28 * -51) / 10) + 45) - -6);
    	a1304128308 = (a470024258 + 2);
    	a1524975081 = (a1425079908 + 12);
    	a297777914 = (((((a533054965 * a533054965) / 5) % 71) - -61) + 9);
    	a635095050 = (a281306570 - -1);
    	a458716067 = (((((((a458716067 * a668543261) % 14999) + -7956) % 38) + -41) + -26615) + 26613);
    	a1281480214 = 32 ;
    	a631351130 = 32 ;
    	a1425079908 = (a470024258 + -6);
    	a558123585 = ((((((a558123585 * a668543261) % 14999) / 5) - 16502) % 32) + 66);
    	a668543261 = ((((((a668543261 * a297777914) % 14999) - -23028) % 96) - -7) - 76);
    	a363377125 = (a462100686 - 6);
    	a470024258 = ((a635095050 + a1304128308) + -6); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } if((((a1350544514 == 33 && (a1809397514 == 33 && a363377125 == 6)) && a1281480214 == 33) && (a668543261 <=  -85 && (( cf==1  && (input == 4)) && a297777914 <=  10)))) {
    	cf = 0;
    	a1178609647 = (a470024258 - -6);
    	a558123585 = ((((((a558123585 * a668543261) % 14999) - -2415) % 14870) - -15129) - 0);
    	a281306570 = (a462100686 - 12); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm4(int input) {
    if(((a533054965 <=  -173 && a1350544514 == 33) && (a631351130 == 33 && ((a635095050 == 4 && ((a462100686 == 12 &&  cf==1 ) && a1809397514 == 33)) && a668543261 <=  -85)))) {
    	calculate_outputm38(input);
    } 
    if((((a1425079908 == 1 && (a668543261 <=  -85 && a631351130 == 33)) && a1350544514 == 33) && ((a1281480214 == 33 && (a462100686 == 13 &&  cf==1 )) && a458716067 <=  -81))) {
    	calculate_outputm39(input);
    } 
}
 void calculate_outputm45(int input) {
    if(((((a1425079908 == 1 && a470024258 == 8) && a668543261 <=  -85) && a363377125 == 6) && ((a635095050 == 4 && ( cf==1  && (input == 10))) && a1350544514 == 33))) {
    	cf = 0;
    	a1281480214 = 32 ;
    	a1350544514 = 32 ;
    	a558123585 = ((((((a558123585 * a458716067) % 14999) % 32) - -44) - 0) - -2);
    	a668543261 = ((((((a668543261 * a533054965) % 14999) % 96) + 7) + -75) + 20);
    	a533054965 = (((((((a533054965 * a668543261) % 14999) % 49) - 123) - 19892) * 1) - -19893);
    	a363377125 = (a635095050 - -3);
    	a631351130 = 32 ;
    	a1524975081 = (a1425079908 - -6);
    	a914727600 = (a470024258 - 6);
    	a470024258 = (a914727600 - -7);
    	a297777914 = ((((((((a297777914 * a493087397) % 14999) % 71) - -81) * 5) - -10705) % 71) + 66);
    	a1425079908 = (a635095050 - 2);
    	a458716067 = (((((a558123585 * a668543261) % 38) - 40) * 1) * 1);
    	a1809397514 = 32 ;
    	a635095050 = ((a281306570 / a363377125) - -5); 
    	 printf("");//printf("%d\n", 23); fflush(stdout); 
    } if((((a1425079908 == 1 && (a1350544514 == 33 && ((a1281480214 == 33 && ((input == 7) &&  cf==1 )) && a668543261 <=  -85))) && (a458716067 <=  -81 && a1809397514 == 33)) && a1287740622 == -13)) {
    	cf = 0;
    	a1034097962 = 33 ;
    	a281306570 = ((a363377125 * a635095050) + -19); 
    	 printf("");//printf("%d\n", 16); fflush(stdout); 
    } if(((a1425079908 == 1 && (a297777914 <=  10 && (((input == 5) &&  cf==1 ) && a470024258 == 8))) && (a533054965 <=  -173 && (a1281480214 == 33 && a631351130 == 33)))) {
    	
    	
    	        if((a1513636275 + 20) > a1513636275)
        {
        a1513636275 +=  3;
        }
        else
        {
        a1513636275 +=  0;
        }	
        
        
    	cf = 0;
    	a1178609647 = (a281306570 - -2);
    	a623007887 = ((((((a493087397 * a493087397) % 14999) % 14919) + 15079) / 5) - -14612);
    	a558123585 = (((((a558123585 * a458716067) % 14999) - 6780) / 5) + 8164); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm6(int input) {
    if(((a668543261 <=  -85 && (a1350544514 == 33 && a533054965 <=  -173)) && (((a470024258 == 8 && (a493087397 <=  3 &&  cf==1 )) && a631351130 == 33) && a1281480214 == 33))) {
    	calculate_outputm45(input);
    } 
}
 void calculate_outputm57(int input) {
    if(((((a470024258 == 9 && a631351130 == 32) && a1350544514 == 32) && ((-85 < a668543261) && (109 >= a668543261))) && (((10 < a297777914) && (153 >= a297777914)) && (((input == 8) &&  cf==1 ) && a363377125 == 7)))) {
    	
    	
    	        if((a1891042067 + 20) > a1891042067)
        {
        a1891042067 +=  2;
        }
        else
        {
        a1891042067 +=  0;
        }	
    	
    	
    	        if((a498158367 - 20) < a498158367)
        {
        a498158367 -=  4;
        }
        else
        {
        a498158367 -=  0;
        }	
        
    	cf = 0;
    	a297777914 = (((a297777914 + -16664) + -8008) - 136);
    	a668543261 = (((((a668543261 * a533054965) * 1) % 14957) - 15041) * 1);
    	a1281480214 = 33 ;
    	a1809397514 = 33 ;
    	a1178609647 = (a914727600 + 5);
    	a533054965 = (((((a533054965 * a668543261) % 14999) - 21502) + -8213) - 256);
    	a1304128308 = ((a635095050 + a470024258) + -4);
    	a558123585 = ((((a558123585 * a458716067) - 23740) / 5) - -24226);
    	a363377125 = (a470024258 - 3);
    	a458716067 = (((((((a297777914 * a297777914) % 14999) - -7846) % 14959) + -15039) / 5) + -7626);
    	a631351130 = 33 ;
    	a1425079908 = (a1524975081 + -6);
    	a1350544514 = 33 ;
    	a635095050 = (a1425079908 - -3);
    	a470024258 = ((a1425079908 - a1304128308) - -17); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } if((((((-173 < a533054965) && (-73 >= a533054965)) && ( cf==1  && (input == 4))) && (a1350544514 == 32 && (a631351130 == 32 && ((a1809397514 == 32 && a363377125 == 7) && a635095050 == 5)))) && a498158367 == -13)) {
    	cf = 0;
    	a2062265878 = (((((a558123585 * a668543261) * 3) + -3466) / 5) + -22672);
    	a558123585 = (((((((a558123585 * a2062265878) % 14999) % 90) + 169) - 19144) - -12545) - -6597);
    	a702083417 = ((a363377125 - a1425079908) - -5); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if(((a470024258 == 9 && (((-173 < a533054965) && (-73 >= a533054965)) && a1809397514 == 32)) && (a1425079908 == 2 && ((((input == 1) &&  cf==1 ) && a363377125 == 7) && ((-81 < a458716067) && (-3 >= a458716067)))))) {

    	
    	        if((a943871142 - 20) < a943871142)
        {
    	a943871142 -=  3;
        }
        else
        {
    	a943871142 -=  0;
        }	
        
    	cf = 0;
    	a1524975081 = (a635095050 + 3);
    	a224147222 = (((((a458716067 * a668543261) % 60) + 411) - 0) * 1); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm59(int input) {
    if(((a635095050 == 5 && ((a363377125 == 7 && (a1350544514 == 32 && ((input == 2) &&  cf==1 ))) && a631351130 == 32)) && (a1281480214 == 32 && a1425079908 == 2))) {
    	
    	
    	        if((a854970918 + 20) > a854970918)
        {
        a854970918 +=  1;
        }
        else
        {
        a854970918 +=  0;
        }	
    	cf = 0;
    	a363377125 = (a1425079908 - -6);
    	a1809397514 = 34 ;
    	a2062265878 = (((((a668543261 * a533054965) - 4987) % 73) + 204) + -1);
    	a533054965 = (((((a297777914 * a297777914) % 101) - 41) + 9872) - 9815);
    	a558123585 = ((((((a558123585 * a458716067) % 90) - -251) + 1) - -29215) - 29239);
    	a1350544514 = 34 ;
    	a458716067 = ((((((a458716067 * a297777914) % 99) - -154) - 24) + -6211) + 6213);
    	a470024258 = (a914727600 - -6);
    	a668543261 = ((((((a668543261 * a2062265878) % 14999) % 15) + 124) - -1) * 1);
    	a1281480214 = 34 ;
    	a631351130 = 34 ;
    	a1425079908 = (a363377125 - 5);
    	a635095050 = (a470024258 + -4);
    	a322697925 = 35 ;
    	a297777914 = (((((((a297777914 * a2062265878) % 14999) - -4194) % 109) + 233) + -1788) + 1724); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if(((a631351130 == 32 && (((10 < a297777914) && (153 >= a297777914)) && a1281480214 == 32)) && (((-85 < a668543261) && (109 >= a668543261)) && (a1425079908 == 2 && (( cf==1  && (input == 8)) && a363377125 == 7))))) {
    	
    	
    	        if((a995729035 + 20) > a995729035)
        {
        a995729035 +=  4;
        }
        else
        {
        a995729035 +=  0;
        }	
        
    	
    	
    	        if((a1958569006 - 20) < a1958569006)
        {
        a1958569006 -=  2;
        }
        else
        {
        a1958569006 -=  0;
        }	
        
    	
    	
    	        if((a1019899841 - 20) < a1019899841)
        {
        a1019899841 -=  2;
        }
        else
        {
        a1019899841 -=  0;
        }	
        
    	cf = 0;
    	a1809397514 = 33 ;
    	a1350544514 = 33 ;
    	a363377125 = ((a1425079908 / a470024258) + 6);
    	a558123585 = ((((a558123585 * a533054965) * 2) + 3931) + 26133);
    	a1281480214 = 33 ;
    	a281306570 = (a1425079908 + 2);
    	a631351130 = 33 ;
    	a458716067 = ((((a458716067 * a668543261) - 10562) - 8648) - 1671);
    	a1178609647 = (a635095050 + 9);
    	a635095050 = (a1524975081 - 3);
    	a668543261 = ((((((a668543261 * a458716067) % 14999) / 5) / 5) * 5) + -21823);
    	a297777914 = (((((a297777914 * a558123585) % 14999) + -27048) - 1266) + -556);
    	a470024258 = (a1524975081 - -1);
    	a533054965 = ((((a533054965 * 10) / 4) + -12288) * 2);
    	a1425079908 = ((a914727600 + a1524975081) - 10); 
    	 printf("");//printf("%d\n", 25); fflush(stdout); 
    } if(((a1281480214 == 32 && ((((10 < a297777914) && (153 >= a297777914)) && ((-173 < a533054965) && (-73 >= a533054965))) && a631351130 == 32)) && (a363377125 == 7 && (( cf==1  && (input == 10)) && a470024258 == 9)))) {
    	cf = 0;
    	 
    	 printf("");//printf("%d\n", 16); fflush(stdout); 
    } if((((a1425079908 == 2 && (a635095050 == 5 && a1350544514 == 32)) && (a1809397514 == 32 && (((-81 < a458716067) && (-3 >= a458716067)) && (a631351130 == 32 && ( cf==1  && (input == 7)))))) && a116248116 == -12)) {
    	
    	
    	        if((a1406068516 - 20) < a1406068516)
        {
        a1406068516 -=  2;
        }
        else
        {
        a1406068516 -=  0;
        }	
        
    	cf = 0;
    	a1524975081 = (a635095050 + 8);
    	a1304128308 = (a470024258 - -3); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } if(((((-85 < a668543261) && (109 >= a668543261)) && ((input == 1) &&  cf==1 )) && ((a470024258 == 9 && (a1281480214 == 32 && (a1350544514 == 32 && a1425079908 == 2))) && ((-173 < a533054965) && (-73 >= a533054965))))) {
    	cf = 0;
    	a281306570 = (a914727600 + 4);
    	a297777914 = ((((a297777914 * a458716067) - 3995) * 1) + -12467);
    	a631351130 = 33 ;
    	a881759693 = ((a1425079908 / a363377125) + 12);
    	a1809397514 = 33 ;
    	a558123585 = ((((a558123585 * a668543261) + -14351) * 1) - 4486);
    	a1281480214 = 33 ;
    	a363377125 = ((a1524975081 + a470024258) - 10);
    	a668543261 = ((((a533054965 * a458716067) - 23127) - 5133) + -628);
    	a1350544514 = 33 ;
    	a470024258 = a281306570;
    	a458716067 = (((((a458716067 * a558123585) % 14999) / 5) - 18875) * 1);
    	a635095050 = (a281306570 + -4);
    	a533054965 = (((((((a533054965 * a297777914) % 14999) * 2) + -1) * 1) % 14913) - 15085);
    	a1425079908 = ((a281306570 / a635095050) + -1); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm9(int input) {
    if(((((-85 < a668543261) && (109 >= a668543261)) && ( cf==1  && a914727600 == 2)) && (a1425079908 == 2 && (a635095050 == 5 && ((a1350544514 == 32 && a470024258 == 9) && a631351130 == 32))))) {
    	calculate_outputm57(input);
    } 
    if((((a363377125 == 7 && ( cf==1  && a914727600 == 4)) && a1809397514 == 32) && ((((-85 < a668543261) && (109 >= a668543261)) && (((10 < a297777914) && (153 >= a297777914)) && a1350544514 == 32)) && ((-81 < a458716067) && (-3 >= a458716067))))) {
    	calculate_outputm59(input);
    } 
}
 void calculate_outputm67(int input) {
    if(((a1425079908 == 2 && (a635095050 == 5 && (a1281480214 == 32 && ((-85 < a668543261) && (109 >= a668543261))))) && ((((input == 2) &&  cf==1 ) && ((-81 < a458716067) && (-3 >= a458716067))) && a1809397514 == 32))) {
    	cf = 0;
    	a281306570 = ((a363377125 + a1524975081) + -13);
    	a668543261 = ((((a668543261 * a458716067) + -5978) + -6387) - 6796);
    	a458716067 = ((((a458716067 * a297777914) / 5) + -1569) * 5);
    	a1425079908 = (a281306570 + -1);
    	a631351130 = 33 ;
    	a1809397514 = 33 ;
    	a558123585 = ((((a558123585 * a533054965) - 8517) + -313) * 1);
    	a1281480214 = 33 ;
    	a470024258 = (a363377125 + 1);
    	a533054965 = ((((((a668543261 * a668543261) % 14999) + 7021) * 10) / -9) * 1);
    	a297777914 = (((((a297777914 * a668543261) % 14999) - 9692) + -214) - 708);
    	a1350544514 = 33 ;
    	a363377125 = (a635095050 - -1); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if(((a635095050 == 5 && (a1425079908 == 2 && ((input == 3) &&  cf==1 ))) && (((a363377125 == 7 && a1350544514 == 32) && a470024258 == 9) && ((-81 < a458716067) && (-3 >= a458716067))))) {
    	cf = 0;
    	a533054965 = (((((a297777914 * a297777914) - 29002) + -1098) - -17560) - 16756);
    	a363377125 = (a470024258 - 3);
    	a1350544514 = 33 ;
    	a1281480214 = 33 ;
    	a1809397514 = 33 ;
    	a458716067 = (((((a458716067 * a533054965) % 14999) - 19643) * 1) - 4618);
    	a462100686 = (a635095050 - -7);
    	a281306570 = (a462100686 + -8);
    	a668543261 = (((((((a668543261 * a224147222) % 14999) % 14957) - 15041) + 23472) - -31) - 23504);
    	a470024258 = ((a363377125 * a1425079908) + -4);
    	a558123585 = ((((((a558123585 * a224147222) % 14999) - 24006) * 10) / 9) * 1);
    	a635095050 = (a363377125 - 2);
    	a1425079908 = ((a1524975081 * a363377125) - 47);
    	a631351130 = 33 ;
    	a297777914 = (((((a297777914 * a458716067) % 14999) / 5) + -13961) * 1); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } if((((a631351130 == 32 && (a635095050 == 5 && (a1350544514 == 32 && ( cf==1  && (input == 6))))) && (a1425079908 == 2 && (((10 < a297777914) && (153 >= a297777914)) && ((-81 < a458716067) && (-3 >= a458716067))))) && a1019899841 <= -47)) {
    	
    	
    	        if((a188376983 + 20) > a188376983)
        {
        a188376983 +=  2;
        }
        else
        {
        a188376983 +=  0;
        }	
        
        
    	cf = 0;
    	a1178609647 = ((a1425079908 * a635095050) + 1);
    	a635095050 = ((a363377125 - a1425079908) + -1);
    	a668543261 = (((((a668543261 * a458716067) * 3) % 14957) - 15041) - 1);
    	a558123585 = ((((((a558123585 * a533054965) * 2) * 1) * 1) * -2) / 10);
    	a1281480214 = 33 ;
    	a533054965 = (((((a224147222 * a297777914) % 14999) + -18924) * 1) / 5);
    	a631351130 = 33 ;
    	a1809397514 = 33 ;
    	a458716067 = ((((((a458716067 * a668543261) % 14999) - 23045) + 7892) - -267) - 11929);
    	a11629652 = 32 ;
    	a363377125 = ((a1178609647 - a1178609647) + 6);
    	a1350544514 = 33 ;
    	a1425079908 = (a470024258 + -8); 
    	 printf("");//printf("%d\n", 23); fflush(stdout); 
    } if(((((a635095050 == 5 && a470024258 == 9) && a363377125 == 7) && ((-85 < a668543261) && (109 >= a668543261))) && ((a1281480214 == 32 && ( cf==1  && (input == 9))) && ((10 < a297777914) && (153 >= a297777914))))) {
    	cf = 0;
    	a1524975081 = ((a363377125 + a635095050) + -5);
    	a914727600 = a363377125; 
    	 printf("");//printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm10(int input) {
    if(((((-81 < a458716067) && (-3 >= a458716067)) && ((a635095050 == 5 && a1425079908 == 2) && a470024258 == 9)) && (a363377125 == 7 && (( cf==1  && 472 < a224147222) && ((-85 < a668543261) && (109 >= a668543261)))))) {
    	calculate_outputm67(input);
    } 
}
 void calculate_outputm71(int input) {
    if(((a635095050 == 5 && ((((-85 < a668543261) && (109 >= a668543261)) && a363377125 == 7) && a1425079908 == 2)) && ((((-173 < a533054965) && (-73 >= a533054965)) && ( cf==1  && (input == 1))) && ((-81 < a458716067) && (-3 >= a458716067))))) {
    	cf = 0;
    	a1350544514 = 34 ;
    	a631351130 = 34 ;
    	a635095050 = (a914727600 - 2);
    	a533054965 = (((((a297777914 * a558123585) % 101) - 8) + -52) - -87);
    	a1281480214 = 34 ;
    	a1809397514 = 34 ;
    	a470024258 = ((a1524975081 * a1425079908) + -8);
    	a2062265878 = ((((((a668543261 * a297777914) % 73) - -204) - 1) - 5580) + 5581);
    	a458716067 = (((((a668543261 * a533054965) % 99) + 97) + -1) - -2);
    	a322697925 = 35 ;
    	a363377125 = ((a1524975081 - a635095050) + 5);
    	a297777914 = ((((((a297777914 * a533054965) % 109) + 263) * 1) / 5) + 173);
    	a558123585 = (((((a558123585 * a2062265878) - -6427) - -968) % 90) + 143);
    	a1425079908 = (a635095050 + -3);
    	a668543261 = (((((a668543261 * a458716067) * 1) * 1) % 15) - -125); 
    	 printf("");//printf("%d\n", 24); fflush(stdout); 
    } if(((( cf==1  && (input == 4)) && a1281480214 == 32) && (a1350544514 == 32 && (a470024258 == 9 && (a363377125 == 7 && (((-85 < a668543261) && (109 >= a668543261)) && a631351130 == 32)))))) {
    	
    	        if((a116248116 - 20) < a116248116)
        {
        a116248116 -=  4;
        }
        else
        {
        a116248116 -=  0;
        }	
    	
    	
    	        if((a426209962 + 20) > a426209962)
        {
        a426209962 +=  6;
        }
        else
        {
        a426209962 +=  0;
        }	

        if((a774092986 + 20) > a774092986)
        {
            	a774092986 +=  1;
        }
        else
        {
    	a774092986 +=  0;
        }	
    	cf = 0;
    	a914727600 = (a470024258 + -5);
    	a1524975081 = ((a363377125 + a914727600) - 4); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } if((((a1281480214 == 32 && (((input == 6) &&  cf==1 ) && a1809397514 == 32)) && ((-81 < a458716067) && (-3 >= a458716067))) && ((a470024258 == 9 && ((-173 < a533054965) && (-73 >= a533054965))) && a635095050 == 5))) {
    	cf = 0;
    	a137310972 = (((((a297777914 * a458716067) / 5) - 4244) % 82) - -119);
    	a631351130 = 33 ;
    	a668543261 = ((((a668543261 * a297777914) + -6381) + -10674) + -61);
    	a1350544514 = 33 ;
    	a1281480214 = 33 ;
    	a558123585 = ((((a558123585 * a137310972) + 13738) - -2503) - -875);
    	a1809397514 = 33 ;
    	a533054965 = ((((a533054965 * a137310972) - 1798) * 1) + -32);
    	a635095050 = 4;
    	a1425079908 = (a1524975081 / a1524975081);
    	a1178609647 = (a363377125 - -5);
    	a363377125 = (a1425079908 - -5);
    	a470024258 = ((a914727600 / a635095050) + 6);
    	a297777914 = (((((a297777914 * a558123585) % 14999) - 18112) * 1) + -3069);
    	a458716067 = ((((a458716067 * a137310972) + -13072) * 1) / 5); 
    	 printf("");//printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm11(int input) {
    if((((((-173 < a533054965) && (-73 >= a533054965)) && (a914727600 == 8 &&  cf==1 )) && a363377125 == 7) && (((10 < a297777914) && (153 >= a297777914)) && ((a1281480214 == 32 && a1350544514 == 32) && a631351130 == 32)))) {
    	calculate_outputm71(input);
    } 
}
 void calculate_outputm77(int input) {
    if(((a363377125 == 7 && (((10 < a297777914) && (153 >= a297777914)) && a1281480214 == 32)) && (((( cf==1  && (input == 8)) && a635095050 == 5) && ((-81 < a458716067) && (-3 >= a458716067))) && a470024258 == 9))) {
    	cf = 0;
    	a1809397514 = 33 ;
    	a1178609647 = (a635095050 - -2);
    	a668543261 = (((94 / 5) - 11421) - 18388);
    	a1304128308 = ((a1425079908 - a1178609647) - -14);
    	a635095050 = (a1304128308 + -5);
    	a558123585 = (((((a558123585 * a458716067) - -8873) - 20666) * 10) / -9);
    	a1281480214 = 33 ;
    	a458716067 = (((((((a668543261 * a558123585) % 14999) / 5) + -4799) - -21941) * -1) / 10);
    	a363377125 = ((a1304128308 / a1524975081) - -6);
    	a1350544514 = 33 ;
    	a533054965 = (((((a533054965 * a558123585) % 14999) - 14798) + -181) * 1);
    	a470024258 = (a1178609647 + 1);
    	a297777914 = (((((a297777914 * a668543261) % 14999) - -16233) / -5) * 5);
    	a1425079908 = (a1178609647 + -6); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } if(((((-173 < a533054965) && (-73 >= a533054965)) && (a635095050 == 5 && a363377125 == 7)) && (((a1350544514 == 32 && ((input == 2) &&  cf==1 )) && a470024258 == 9) && ((-81 < a458716067) && (-3 >= a458716067))))) {
    	
    	if((a1958569006 + 20) > a1958569006)
        {
        a1958569006 += 4;
        }
        else
        {
        a1958569006 += 0;
        }	
    	
    	if((a1019899841 + 20) > a1019899841)
        {
        a1019899841 +=  1;
        }
        else
        {
        a1019899841 +=  0;
        }	
    	cf = 0;
    	a363377125 = (a470024258 + -3);
    	a1178609647 = (a754697839 - 3);
    	a1350544514 = 33 ;
    	a1809397514 = 33 ;
    	a533054965 = ((((a533054965 * a297777914) * 1) - 1050) - 660);
    	a1281480214 = 33 ;
    	a635095050 = ((a1425079908 - a1425079908) + 4);
    	a558123585 = ((((((a558123585 * a668543261) * 3) / 5) * 5) % 14870) + 15129);
    	a11629652 = 34 ;
    	a470024258 = ((a1178609647 * a363377125) + -58); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm12(int input) {
    if((((( cf==1  && a754697839 == 14) && a1281480214 == 32) && a635095050 == 5) && (((-173 < a533054965) && (-73 >= a533054965)) && ((((-81 < a458716067) && (-3 >= a458716067)) && a1809397514 == 32) && a470024258 == 9)))) {
    	calculate_outputm77(input);
    } 
}
 void calculate_outputm85(int input) {
    if(((a1425079908 == 2 && (((((-81 < a458716067) && (-3 >= a458716067)) && a1350544514 == 32) && ((-85 < a668543261) && (109 >= a668543261))) && ((10 < a297777914) && (153 >= a297777914)))) && (a1281480214 == 32 && ((input == 3) &&  cf==1 )))) {
    	
    	        if((a1647447633 + 20) > a1647447633)
        {
        a1647447633 +=  2;
        }
        else
        {
        a1647447633 +=  0;
        }	
    	
    	        if((a333446562 - 20) < a333446562)
        {
        a333446562 -=  6;
        }
        else
        {
        a333446562 -=  0;
        }	
    	
    	        if((a758764692 + 20) > a758764692)
        {
        a758764692 +=  4;
        }
        else
        {
        a758764692 +=  0;
        }	
    	
    	        if((a2027636238 - 20) < a2027636238)
        {
        a2027636238 -=  4;
        }
        else
        {
        a2027636238 -=  0;
        }	
    	
    	        if((a2061130608 + 20) > a2061130608)
        {
        a2061130608 +=  1;
        }
        else
        {
        a2061130608 +=  0;
        }	
    	
    	        if((a943871142 + 20) > a943871142)
        {
        a943871142 +=  1;
        }
        else
        {
        a943871142 +=  0;
        }	
    	cf = 0;
    	a387693620 = ((a1524975081 + a363377125) + -7); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if(((((10 < a297777914) && (153 >= a297777914)) && (a635095050 == 5 && (a631351130 == 32 && a1350544514 == 32))) && ((a1425079908 == 2 && ((input == 10) &&  cf==1 )) && a1281480214 == 32))) {
    	cf = 0;
    	a387693620 = (a470024258 + 3); 
    	 printf("");//printf("%d\n", 20); fflush(stdout); 
    } if(((((a1809397514 == 32 && (a1425079908 == 2 && ( cf==1  && (input == 2)))) && ((-85 < a668543261) && (109 >= a668543261))) && (a1281480214 == 32 && (((-81 < a458716067) && (-3 >= a458716067)) && a631351130 == 32))) && a188376983 <= -26)) {
    	
    	        if((a943871142 - 20) < a943871142)
        {
        a943871142 -=  1;
        }
        else
        {
        a943871142 -=  0;
        }	
    	cf = 0;
    	a458716067 = (((((a458716067 * a533054965) * 2) % 99) - 1) + 24);
    	a2062265878 = ((((((a668543261 * a297777914) + 13313) * 1) / 5) * 41) / 10);
    	a1425079908 = (a1524975081 - 9);
    	a1281480214 = 34 ;
    	a1350544514 = 34 ;
    	a631351130 = 34 ;
    	a631219524 = (a635095050 - -5);
    	a297777914 = (((((a668543261 * a668543261) + -6739) % 109) + 263) + -1);
    	a533054965 = ((((((a458716067 * a458716067) % 14999) % 101) - -29) / 5) + -54);
    	a635095050 = (a387693620 - 2);
    	a558123585 = (((((((a558123585 * a2062265878) % 14999) % 90) - -131) - -29) * 9) / 10);
    	a363377125 = (a1425079908 - -5);
    	a1809397514 = 34 ;
    	a668543261 = (((((a668543261 * a458716067) % 15) + 124) - -2) - 1); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } if(((((((-81 < a458716067) && (-3 >= a458716067)) && (((10 < a297777914) && (153 >= a297777914)) && (((-85 < a668543261) && (109 >= a668543261)) && ( cf==1  && (input == 6))))) && a1809397514 == 32) && (a363377125 == 7 && a470024258 == 9)) && a2061130608 == 19)) {
    	cf = 0;
    	a224147222 = (((((a533054965 * a558123585) % 78) - -296) + -3951) + 3943);
    	a1524975081 = ((a635095050 / a1425079908) + 6); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if((((((a470024258 == 9 && ((-173 < a533054965) && (-73 >= a533054965))) && ((-81 < a458716067) && (-3 >= a458716067))) && a1809397514 == 32) && (((-85 < a668543261) && (109 >= a668543261)) && (((input == 1) &&  cf==1 ) && a1425079908 == 2))) && a943871142 == 43)) {
    	
    	        if((a188376983 + 20) > a188376983)
        {
        a188376983 +=  2;
        }
        else
        {
        a188376983 +=  0;
        }	
    	cf = 0;
    	a1304128308 = a470024258;
    	a1524975081 = (a1425079908 + 11); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if(((((((input == 5) &&  cf==1 ) && a631351130 == 32) && a470024258 == 9) && (a1350544514 == 32 && (a635095050 == 5 && (a363377125 == 7 && a1425079908 == 2)))) && a521016673 <= -83)) {
    	cf = 0;
    	a1524975081 = (a363377125 - -3);
    	a754697839 = (a1524975081 + 5); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } if(((((a631351130 == 32 && (a1809397514 == 32 && ((-85 < a668543261) && (109 >= a668543261)))) && ((-81 < a458716067) && (-3 >= a458716067))) && (a1350544514 == 32 && (((10 < a297777914) && (153 >= a297777914)) && ((input == 8) &&  cf==1 )))) && a1513636275 <= -44)) {
    	cf = 0;
    	a1524975081 = (a470024258 + 2);
    	a306593017 = ((((a558123585 * a668543261) - 19967) / 5) * 5); 
    	 printf("");//printf("%d\n", 26); fflush(stdout); 
    } if(((((a1425079908 == 2 && ((-173 < a533054965) && (-73 >= a533054965))) && a363377125 == 7) && a1350544514 == 32) && (a470024258 == 9 && (a631351130 == 32 && ((input == 9) &&  cf==1 ))))) {
    	cf = 0;
    	a754697839 = ((a363377125 * a635095050) - 22);
    	a1524975081 = (a387693620 + 2); 
    	 printf("");//printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm86(int input) {
    if(((a470024258 == 9 && (((-85 < a668543261) && (109 >= a668543261)) && a1425079908 == 2)) && (((((-81 < a458716067) && (-3 >= a458716067)) && ( cf==1  && (input == 1))) && ((10 < a297777914) && (153 >= a297777914))) && a635095050 == 5))) {
    	
    	        if((a815200306 + 20) > a815200306)
        {
        a815200306 +=  6;
        }
        else
        {
        a815200306 +=  0;
        }	
    	
    	        if((a1449483205 + 20) > a1449483205)
        {
        a1449483205 +=  6;
        }
        else
        {
        a1449483205 +=  0;
        }	
    	
    	        if((a1513636275 - 20) < a1513636275)
        {
        a1513636275 -=  2;
        }
        else
        {
        a1513636275 -=  0;
        }	
    	
    	        if((a2061130608 - 20) < a2061130608)
        {
        a2061130608 -=  1;
        }
        else
        {
        a2061130608 -=  0;
        }	
    	cf = 0;
    	a387693620 = (a635095050 + 7); 
    	 printf("");//printf("%d\n", 20); fflush(stdout); 
    } if(((((10 < a297777914) && (153 >= a297777914)) && (a1281480214 == 32 && ((-85 < a668543261) && (109 >= a668543261)))) && (a635095050 == 5 && (a470024258 == 9 && (a1425079908 == 2 && ( cf==1  && (input == 3))))))) {
    	
    	        if((a854970918 - 20) < a854970918)
        {
        a854970918 -=  4;
        }
        else
        {
        a854970918 -=  0;
        }	
    	
    	        if((a1323714376 - 20) < a1323714376)
        {
        a1323714376 -=  4;
        }
        else
        {
        a1323714376 -=  0;
        }	
    	
    	        if((a188376983 - 20) < a188376983)
        {
        a188376983 -=  2;
        }
        else
        {
        a188376983 -=  0;
        }	
    	cf = 0;
    	a387693620 = (a1425079908 + 6); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } if(((((((10 < a297777914) && (153 >= a297777914)) && a1281480214 == 32) && ((-85 < a668543261) && (109 >= a668543261))) && (a1350544514 == 32 && (a635095050 == 5 && (a1809397514 == 32 && ((input == 5) &&  cf==1 ))))) && a758764692 == 6)) {
    	
    	if((a943871142 - 20) < a943871142)
        {
        a943871142 -=  1;
        }
        else
        {
        a943871142 -=  0;
        }	
    	cf = 0;
    	a558123585 = ((((a558123585 * a668543261) + 9141) - 760) * 1);
    	a61424176 = ((a470024258 * a635095050) + -37);
    	a1178609647 = ((a1524975081 / a1524975081) + 9); 
    	 printf("");//printf("%d\n", 26); fflush(stdout); 
    } if((((((10 < a297777914) && (153 >= a297777914)) && a1425079908 == 2) && ((((((-173 < a533054965) && (-73 >= a533054965)) && ((input == 10) &&  cf==1 )) && a470024258 == 9) && a635095050 == 5) && a1281480214 == 32)) && a2027636238 == -20)) {
    	cf = 0;
    	a558123585 = (((((a558123585 * a297777914) / 5) / 5) * 5) * -5);
    	a1034097962 = 32 ;
    	a281306570 = (a363377125 - 2); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if((((a631351130 == 32 && (a1281480214 == 32 && (( cf==1  && (input == 4)) && ((-173 < a533054965) && (-73 >= a533054965))))) && (((10 < a297777914) && (153 >= a297777914)) && (a635095050 == 5 && ((-81 < a458716067) && (-3 >= a458716067))))) && a815200306 == 12)) {
    	
    	        if((a774092986 - 20) < a774092986)
        {
        a774092986 -=  3;
        }
        else
        {
        a774092986 -=  0;
        }	
    	cf = 0;
    	a558123585 = ((((a558123585 * a458716067) + -16347) * 1) / 5);
    	a281306570 = ((a1425079908 - a363377125) + 11);
    	a493087397 = ((((((((a558123585 * a297777914) % 14999) % 91) - -215) - -9577) * 3) % 91) - -142); 
    	 printf("");//printf("%d\n", 20); fflush(stdout); 
    } if((((a635095050 == 5 && (((-81 < a458716067) && (-3 >= a458716067)) && a1425079908 == 2)) && (((( cf==1  && (input == 8)) && a1350544514 == 32) && ((-85 < a668543261) && (109 >= a668543261))) && a1281480214 == 32)) && a204693615 == 5)) {
    	
    	        if((a188376983 + 20) > a188376983)
        {
        a188376983 +=  2;
        }
        else
        {
        a188376983 +=  0;
        }	
    	cf = 0;
    	a1178609647 = ((a470024258 + a635095050) + -4);
    	a61424176 = (a1425079908 - -7);
    	a558123585 = ((((a558123585 * a297777914) + 12037) / 5) / 5); 
    	 printf("");//printf("%d\n", 26); fflush(stdout); 
    } if(((((a470024258 == 9 && a1281480214 == 32) && a1809397514 == 32) && (((a1425079908 == 2 && ((input == 6) &&  cf==1 )) && ((-173 < a533054965) && (-73 >= a533054965))) && ((10 < a297777914) && (153 >= a297777914)))) && a1079276458 == -3)) {
    	
    	        if((a521016673 + 20) > a521016673)
        {
        a521016673 +=  4;
        }
        else
        {
        a521016673 +=  0;
        }	
    	cf = 0;
    	a558123585 = (((((a558123585 * a297777914) + -21083) - -23013) * 2) * -1);
    	a881759693 = (a1524975081 - 6);
    	a281306570 = (a635095050 - -3); 
    	 printf("");//printf("%d\n", 20); fflush(stdout); 
    } if(((a1350544514 == 32 && ((-81 < a458716067) && (-3 >= a458716067))) && ((a635095050 == 5 && (a363377125 == 7 && (a1281480214 == 32 && ((input == 7) &&  cf==1 )))) && a1425079908 == 2))) {
    	
    	if((a1019899841 + 20) > a1019899841)
        {
        a1019899841 +=  2;
        }
        else
        {
        a1019899841 +=  0;
        }	
    	cf = 0;
    	a1281480214 = 34 ;
    	a470024258 = (a1524975081 - 2);
    	a558123585 = (((((((a558123585 * a533054965) % 90) + 208) * 10) / 9) * 10) / 9);
    	a322697925 = 33 ;
    	a363377125 = (a635095050 + 3);
    	a1425079908 = (a387693620 - 6);
    	a533054965 = (((((a533054965 * a297777914) - -1482) % 101) - -29) - 1);
    	a1350544514 = 34 ;
    	a1809397514 = 34 ;
    	a631351130 = 34 ;
    	a2062265878 = ((((((a668543261 * a668543261) % 73) + 204) - -5411) / 5) - 967);
    	a297777914 = ((((((a668543261 * a458716067) * 3) - 1352) + -1394) % 109) + 263);
    	a458716067 = (((((a458716067 * a668543261) - 4277) - 5500) % 99) - -164);
    	a668543261 = (((((a668543261 + -12872) % 15) - -125) - -21246) - 21239); 
    	 printf("");//printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm88(int input) {
    if(((((-85 < a668543261) && (109 >= a668543261)) && ((a635095050 == 5 && (a1350544514 == 32 && ((input == 3) &&  cf==1 ))) && a363377125 == 7)) && (((-81 < a458716067) && (-3 >= a458716067)) && a631351130 == 32))) {
    	
    	if((a1717797827 + 20) > a1717797827)
        {
        a1717797827 +=  6;
        }
        else
        {
        a1717797827 +=  0;
        }	
    	cf = 0;
    	a387693620 = ((a1524975081 * a1425079908) + -15); 
    	 printf("");//printf("%d\n", 16); fflush(stdout); 
    } if(((a470024258 == 9 && (((-81 < a458716067) && (-3 >= a458716067)) && ( cf==1  && (input == 7)))) && (((10 < a297777914) && (153 >= a297777914)) && (a1350544514 == 32 && (a1281480214 == 32 && a631351130 == 32))))) {
    	
    	        if((a1783572941 + 20) > a1783572941)
        {
        a1783572941 +=  6;
        }
        else
        {
        a1783572941 +=  0;
        }	
    	
    	        if((a204693615 + 20) > a204693615)
        {
        a204693615 +=  4;
        }
        else
        {
        a204693615 +=  0;
        }	
    	
    	        if((a521016673 - 20) < a521016673)
        {
        a521016673 -=  4;
        }
        else
        {
        a521016673 -=  0;
        }	
    	cf = 0;
    	a668543261 = ((((((66 * -13) / 10) * 5) - -20441) * -1) / 10);
    	a631351130 = 33 ;
    	a297777914 = (((((a297777914 * a668543261) % 14999) - 13319) - 10) + -1659);
    	a470024258 = (a1425079908 - -6);
    	a1281480214 = 33 ;
    	a1425079908 = ((a1524975081 / a635095050) - 1);
    	a533054965 = ((((((a297777914 * a668543261) % 14999) % 14913) + -15085) + -1) - 1);
    	a281306570 = ((a1524975081 - a363377125) + 1);
    	a1178609647 = ((a281306570 - a387693620) + 20);
    	a1809397514 = 33 ;
    	a558123585 = (((((a558123585 * a458716067) + -21609) * -1) / 10) + 13456);
    	a458716067 = ((((((a458716067 * a533054965) % 14999) - 28598) * 1) + 26739) + -14133);
    	a363377125 = (a1524975081 + -6);
    	a1350544514 = 33 ;
    	a635095050 = (a1524975081 + -8); 
    	 printf("");//printf("%d\n", 23); fflush(stdout); 
    } if(((((a1350544514 == 32 && (((-85 < a668543261) && (109 >= a668543261)) && a1425079908 == 2)) && a631351130 == 32) && ((( cf==1  && (input == 2)) && a363377125 == 7) && a1281480214 == 32)) && a995729035 == 16)) {
    	
    	        if((a943871142 - 20) < a943871142)
        {
        a943871142 -=  4;
        }
        else
        {
        a943871142 -=  0;
        }	
    	cf = 0;
    	a2086194771 = 34 ;
    	a1524975081 = (a363377125 - -7); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm14(int input) {
    if((((a387693620 == 8 &&  cf==1 ) && a1281480214 == 32) && (((-81 < a458716067) && (-3 >= a458716067)) && (a635095050 == 5 && ((((10 < a297777914) && (153 >= a297777914)) && a1809397514 == 32) && a363377125 == 7))))) {
    	calculate_outputm85(input);
    } 
    if((((a470024258 == 9 && (a1281480214 == 32 && a1425079908 == 2)) && ((-173 < a533054965) && (-73 >= a533054965))) && ((a363377125 == 7 && ( cf==1  && a387693620 == 9)) && a1350544514 == 32))) {
    	calculate_outputm86(input);
    } 
    if(((a1350544514 == 32 && (a635095050 == 5 && (a387693620 == 12 &&  cf==1 ))) && (((-81 < a458716067) && (-3 >= a458716067)) && (a1281480214 == 32 && (a1809397514 == 32 && a470024258 == 9))))) {
    	calculate_outputm88(input);
    } 
}
 void calculate_outputm92(int input) {
    if((a470024258 == 9 && ((a631351130 == 32 && (a363377125 == 7 && (((-173 < a533054965) && (-73 >= a533054965)) && (((input == 3) &&  cf==1 ) && a635095050 == 5)))) && ((-81 < a458716067) && (-3 >= a458716067))))) {
    	cf = 0;
    	a470024258 = (a1524975081 + -5);
    	a462100686 = (a635095050 - -8);
    	a558123585 = ((((a558123585 * a458716067) * 4) + -2648) + -2436);
    	a1281480214 = 33 ;
    	a297777914 = ((((a297777914 * a668543261) * 1) + -17066) * 1);
    	a1350544514 = 33 ;
    	a281306570 = (a1425079908 + 2);
    	a533054965 = ((((((a533054965 * a297777914) % 14999) % 14913) + -15085) / 5) + -17066);
    	a458716067 = (((((a297777914 * a558123585) % 14999) / 5) + -22241) * 1);
    	a668543261 = (((92 + -6427) + -23347) * 1);
    	a1809397514 = 33 ;
    	a363377125 = ((a470024258 / a1304128308) - -6);
    	a631351130 = 33 ;
    	a635095050 = (a1425079908 - -2);
    	a1425079908 = (a1304128308 + -9); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } if(((((((-81 < a458716067) && (-3 >= a458716067)) && ((input == 5) &&  cf==1 )) && ((-173 < a533054965) && (-73 >= a533054965))) && ((a635095050 == 5 && (a1350544514 == 32 && a1809397514 == 32)) && ((-85 < a668543261) && (109 >= a668543261)))) && a774092986 == 30)) {
    	
    	        if((a2061130608 - 20) < a2061130608)
        {
        a2061130608 -=  4;
        }
        else
        {
        a2061130608 -=  0;
        }	
    	cf = 0;
    	a1809397514 = 33 ;
    	a635095050 = ((a363377125 * a1304128308) - 66);
    	a470024258 = (a1524975081 - 5);
    	a281306570 = (a1524975081 + -6);
    	a631351130 = 33 ;
    	a1350544514 = 33 ;
    	a1425079908 = (a635095050 + -3);
    	a230802418 = 36 ;
    	a668543261 = ((((((a668543261 * a458716067) - 17012) / 5) + 18407) * -1) / 10);
    	a363377125 = (a1524975081 - 7);
    	a558123585 = ((((a558123585 * a533054965) - 7415) - 8031) * 1);
    	a1281480214 = 33 ;
    	a533054965 = ((((a533054965 * a458716067) / 5) + -11936) + -9708); 
    	 printf("");//printf("%d\n", 25); fflush(stdout); 
    } if(((((10 < a297777914) && (153 >= a297777914)) && (a1425079908 == 2 && a1350544514 == 32)) && ((a470024258 == 9 && (((-81 < a458716067) && (-3 >= a458716067)) && ( cf==1  && (input == 6)))) && ((-173 < a533054965) && (-73 >= a533054965))))) {
    	cf = 0;
    	a533054965 = ((((((a533054965 * a668543261) - 8951) * 1) - 1619) % 101) - -29);
    	a702083417 = ((a1425079908 * a470024258) - 14);
    	a363377125 = ((a1524975081 * a1304128308) - 122);
    	a558123585 = ((((((a558123585 * a458716067) - -10423) * 2) / 5) % 90) + 128);
    	a635095050 = ((a702083417 + a470024258) + -7);
    	a1809397514 = 34 ;
    	a1425079908 = (a702083417 - 1);
    	a631351130 = 34 ;
    	a1350544514 = 34 ;
    	a1281480214 = 34 ;
    	a2062265878 = ((((((a558123585 * a668543261) % 15065) + -14934) - -3031) * 1) - 3031);
    	a297777914 = ((((((a297777914 * a558123585) % 14999) - 28395) * 1) % 109) + 272);
    	a668543261 = (((((a458716067 * a533054965) % 15) - -124) * 1) - -2);
    	a458716067 = ((((((a458716067 * a533054965) * 2) * 1) - 7113) % 99) - -97); 
    	 printf("");//printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm15(int input) {
    if((((a1304128308 == 10 &&  cf==1 ) && ((-81 < a458716067) && (-3 >= a458716067))) && ((((a635095050 == 5 && ((-173 < a533054965) && (-73 >= a533054965))) && a1809397514 == 32) && a1425079908 == 2) && ((10 < a297777914) && (153 >= a297777914))))) {
    	calculate_outputm92(input);
    } 
}
 void calculate_outputm102(int input) {
    if(((a470024258 == 10 && (((153 < a297777914) && (372 >= a297777914)) && a1281480214 == 34)) && (((-3 < a458716067) && (197 >= a458716067)) && ((( cf==1  && (input == 8)) && ((109 < a668543261) && (140 >= a668543261))) && ((-73 < a533054965) && (130 >= a533054965)))))) {
    	
    	        if((a1406068516 + 20) > a1406068516)
        {
        a1406068516 +=  2;
        }
        else
        {
        a1406068516 +=  0;
        }	
    	cf = 0;
    	a363377125 = (a702083417 - 5);
    	a493087397 = (((((((a668543261 * a558123585) % 14999) % 59) - -34) + -27) - 10363) + 10381);
    	a1809397514 = 33 ;
    	a1350544514 = 33 ;
    	a558123585 = (((((a558123585 * a458716067) % 14999) + 4176) - 19163) - 9);
    	a281306570 = (a635095050 - 5);
    	a533054965 = (((((((a533054965 * a558123585) % 14999) - 14563) / 5) * 5) % 14913) - 15085);
    	a631351130 = 33 ;
    	a470024258 = (a635095050 - -2);
    	a668543261 = ((((49 * -18) / 10) * 5) * 5);
    	a1281480214 = 33 ;
    	a297777914 = (((((a297777914 * a458716067) % 14999) / 5) + -25919) * 1);
    	a458716067 = ((((((a458716067 * a2062265878) % 14999) - -9171) % 14959) - 15039) * 1);
    	a635095050 = (a1425079908 + 1);
    	a1425079908 = (a470024258 + -7); 
    	 printf("");//printf("%d\n", 23); fflush(stdout); 
    } if(((((-73 < a533054965) && (130 >= a533054965)) && ((a363377125 == 8 && a1350544514 == 34) && ((153 < a297777914) && (372 >= a297777914)))) && (((-3 < a458716067) && (197 >= a458716067)) && (( cf==1  && (input == 2)) && a635095050 == 6)))) {
    	
    	        if((a1471952247 - 20) < a1471952247)
        {
        a1471952247 -=  4;
        }
        else
        {
        a1471952247 -=  0;
        }	
    	
    	        if((a706425043 + 20) > a706425043)
        {
        a706425043 +=  1;
        }
        else
        {
        a706425043 +=  0;
        }	
    	cf = 0;
    	a558123585 = ((((((a558123585 * a2062265878) % 14999) % 14870) - -15129) + 0) * 1);
    	a1178609647 = (a635095050 + 8);
    	a631351130 = 33 ;
    	a1281480214 = 33 ;
    	a363377125 = (a470024258 - 4);
    	a1809397514 = 33 ;
    	a281306570 = (a1425079908 - -2);
    	a533054965 = ((((a533054965 * a668543261) - 18738) * 1) + -829);
    	a458716067 = ((((((a458716067 * a297777914) % 14999) % 14959) - 15039) - 1) + -1);
    	a668543261 = (((((a558123585 * a558123585) % 14999) - 29337) - 410) * 1);
    	a635095050 = (a363377125 + -2); 
    	 printf("");//printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm17(int input) {
    if(((a1281480214 == 34 && (((153 < a297777914) && (372 >= a297777914)) && a363377125 == 8)) && (((-73 < a533054965) && (130 >= a533054965)) && (a631351130 == 34 && ((a702083417 == 11 &&  cf==1 ) && a1350544514 == 34))))) {
    	calculate_outputm102(input);
    } 
}
 void calculate_outputm105(int input) {
    if(((((109 < a668543261) && (140 >= a668543261)) && (a470024258 == 10 && a1281480214 == 34)) && (a1425079908 == 3 && ((( cf==1  && (input == 3)) && a631351130 == 34) && ((-73 < a533054965) && (130 >= a533054965)))))) {
    	cf = 0;
    	 
    	 printf("");//printf("%d\n", 24); fflush(stdout); 
    } if(((a363377125 == 8 && (((109 < a668543261) && (140 >= a668543261)) && (((153 < a297777914) && (372 >= a297777914)) && a1281480214 == 34))) && (a1425079908 == 3 && (a1809397514 == 34 && ( cf==1  && (input == 9)))))) {
    	cf = 0;
    	a1524975081 = (a1425079908 + 5);
    	a470024258 = ((a1524975081 + a1425079908) + -2);
    	a558123585 = ((((((a558123585 * a668543261) % 14999) % 32) - -15) + -5707) + 5724);
    	a458716067 = ((((((a458716067 * a533054965) / 5) - 20028) / 5) % 38) - 40);
    	a363377125 = ((a1425079908 - a1425079908) + 7);
    	a668543261 = ((((((a668543261 * a558123585) % 96) - 2) / 5) - -26465) + -26410);
    	a224147222 = (((((a297777914 * a297777914) % 14999) + 12140) + 1334) / 5);
    	a635095050 = ((a1425079908 * a363377125) - 16);
    	a631351130 = 32 ;
    	a1809397514 = 32 ;
    	a1350544514 = 32 ;
    	a297777914 = (((((a458716067 * a2062265878) % 71) - -121) - -2981) - 2967);
    	a533054965 = (((((((a533054965 * a2062265878) % 14999) % 49) - 121) + -2) + -19657) - -19658);
    	a1281480214 = 32 ;
    	a1425079908 = ((a635095050 - a470024258) + 6); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if((((a363377125 == 8 && (a1425079908 == 3 && ((a631351130 == 34 && a1350544514 == 34) && ((-3 < a458716067) && (197 >= a458716067))))) && (a1281480214 == 34 && ( cf==1  && (input == 10)))) && a426209962 == 7)) {
    	cf = 0;
    	a493087397 = (((((((a558123585 * a533054965) % 14999) + 13596) / 5) + -11126) % 91) - -255);
    	a281306570 = (a1425079908 + -2);
    	a558123585 = (((((a558123585 * a458716067) % 14999) - 14996) - -343) + -336); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } if((((((109 < a668543261) && (140 >= a668543261)) && (((-73 < a533054965) && (130 >= a533054965)) && (a631351130 == 34 && a1281480214 == 34))) && ((-3 < a458716067) && (197 >= a458716067))) && (a1350544514 == 34 && ((input == 5) &&  cf==1 )))) {
    	cf = 0;
    	a1350544514 = 33 ;
    	a1809397514 = 33 ;
    	a281306570 = (a635095050 + 1);
    	a558123585 = ((((((a558123585 * a2062265878) % 14999) - 12601) * 2) * 1) + -4795);
    	a458716067 = (((((a2062265878 * a2062265878) % 14999) - 19515) / 5) * 5);
    	a230802418 = 34 ;
    	a631351130 = 33 ;
    	a668543261 = ((((((a668543261 * a297777914) % 14999) / 5) - -16579) - -8937) - 41209);
    	a533054965 = (((((a533054965 * a458716067) % 14999) - -14031) / 5) + -21647);
    	a363377125 = (a1425079908 - -3);
    	a470024258 = (a1425079908 + 5);
    	a1281480214 = 33 ;
    	a1425079908 = ((a635095050 * a281306570) + -41); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm18(int input) {
    if(((a631351130 == 34 && (a635095050 == 6 && (a322697925 == 35 &&  cf==1 ))) && ((a1350544514 == 34 && (a470024258 == 10 && a1425079908 == 3)) && ((109 < a668543261) && (140 >= a668543261))))) {
    	calculate_outputm105(input);
    } 
}
 void calculate_outputm119(int input) {
    if(((a1809397514 == 33 && (a297777914 <=  10 && a1281480214 == 33)) && (a363377125 == 6 && (a631351130 == 33 && (((input == 3) &&  cf==1 ) && a1350544514 == 33))))) {
    	cf = 0;
    	 
    	 printf("");//printf("%d\n", 20); fflush(stdout); 
    } if((((a635095050 == 4 && a1425079908 == 1) && a1350544514 == 33) && (a458716067 <=  -81 && (a1809397514 == 33 && (a1281480214 == 33 && ( cf==1  && (input == 7))))))) {
    	
    	        if((a1471952247 - 20) < a1471952247)
        {
        a1471952247 -=  4;
        }
        else
        {
        a1471952247 -=  0;
        }	
    	cf = 0;
    	 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if(((((a470024258 == 8 && a1350544514 == 33) && a297777914 <=  10) && (a458716067 <=  -81 && ((( cf==1  && (input == 9)) && a631351130 == 33) && a363377125 == 6))) && a1449483205 == 13)) {
    	cf = 0;
    	a914727600 = ((a470024258 / a635095050) - -3);
    	a558123585 = (((((((a558123585 * a668543261) % 14999) - -17303) % 32) - -45) + 14058) - 14084);
    	a1524975081 = ((a1178609647 * a363377125) + -35); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if(((((a668543261 <=  -85 && a1350544514 == 33) && a1425079908 == 1) && (a533054965 <=  -173 && ((((input == 2) &&  cf==1 ) && a458716067 <=  -81) && a635095050 == 4))) && a2070216165 == 9)) {
    	cf = 0;
    	a1524975081 = (a635095050 - -5);
    	a914727600 = ((a1304128308 - a363377125) + -1);
    	a558123585 = ((((((a558123585 * a297777914) % 14999) % 32) - -44) / 5) + 12); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if((((((a1809397514 == 33 && (a1350544514 == 33 && a1425079908 == 1)) && a470024258 == 8) && a458716067 <=  -81) && (((input == 8) &&  cf==1 ) && a533054965 <=  -173)) && a1958569006 <= -4)) {
    	cf = 0;
    	a281306570 = ((a1304128308 / a1304128308) - -7);
    	a558123585 = (((((a558123585 * a297777914) % 14999) - 14986) / 5) + -19523);
    	a881759693 = (a281306570 + 5); 
    	 printf("");//printf("%d\n", 16); fflush(stdout); 
    } if(((((a297777914 <=  10 && ((( cf==1  && (input == 5)) && a1281480214 == 33) && a635095050 == 4)) && a533054965 <=  -173) && (a470024258 == 8 && a1809397514 == 33)) && a1471952247 == 5)) {
    	
    	        if((a854970918 + 20) > a854970918)
        {
        a854970918 +=  1;
        }
        else
        {
        a854970918 +=  0;
        }	
    	cf = 0;
    	a61424176 = ((a635095050 / a1304128308) + 11);
    	a1178609647 = (a1304128308 + 1); 
    	 printf("");//printf("%d\n", 26); fflush(stdout); 
    } if(((((a668543261 <=  -85 && ((a1281480214 == 33 && a1809397514 == 33) && a631351130 == 33)) && a635095050 == 4) && (( cf==1  && (input == 1)) && a1350544514 == 33)) && a854970918 <= -24)) {
    	
    	        if((a854970918 + 20) > a854970918)
        {
        a854970918 +=  3;
        }
        else
        {
        a854970918 +=  0;
        }	
    	cf = 0;
    	a668543261 = ((((12 * 92) / 10) * 5) - 418);
    	a363377125 = (a1304128308 - 1);
    	a631219524 = (a635095050 + 9);
    	a2062265878 = (((((a297777914 * a458716067) % 14999) + -5005) / 5) + 5295);
    	a1809397514 = 34 ;
    	a631351130 = 34 ;
    	a1281480214 = 34 ;
    	a558123585 = ((((((a558123585 * a533054965) % 14999) - -28982) + 828) % 90) + 140);
    	a470024258 = (a631219524 - 3);
    	a533054965 = ((((((a668543261 * a668543261) % 101) - -7) + 5) * 10) / 9);
    	a458716067 = ((((((a2062265878 * a558123585) % 14999) - 3219) % 99) + 96) + 3);
    	a297777914 = ((((((a668543261 * a668543261) % 109) - -226) + -6990) + -19711) + 26660);
    	a1350544514 = 34 ;
    	a635095050 = (a1304128308 - 3); 
    	 printf("");//printf("%d\n", 25); fflush(stdout); 
    } if(((((( cf==1  && (input == 4)) && a297777914 <=  10) && a668543261 <=  -85) && (((a1281480214 == 33 && a470024258 == 8) && a1425079908 == 1) && a631351130 == 33)) && a1406068516 == 21)) {
    	cf = 0;
    	a2062265878 = ((((((a558123585 * a533054965) % 14999) % 73) + 203) + -27413) + 27414);
    	a533054965 = ((((((a668543261 * a2062265878) % 14999) - -8017) % 101) + 28) - 0);
    	a1350544514 = 34 ;
    	a322697925 = 36 ;
    	a558123585 = (((((((a558123585 * a458716067) % 14999) - 13241) - 775) / 5) % 90) - -203);
    	a1281480214 = 34 ;
    	a470024258 = (a363377125 - -4);
    	a458716067 = (((((((a458716067 * a2062265878) % 14999) % 99) - -97) + 1) - 28090) - -28088);
    	a363377125 = (a1425079908 + 7);
    	a1809397514 = 34 ;
    	a631351130 = 34 ;
    	a668543261 = (((((((((a2062265878 * a2062265878) % 14999) % 15) + 125) * 9) / 10) / 5) * 51) / 10);
    	a297777914 = ((((((((a297777914 * a2062265878) % 14999) % 109) + 262) - -1) * 5) % 109) - -216);
    	a1425079908 = (a1178609647 - 4); 
    	 printf("");//printf("%d\n", 23); fflush(stdout); 
    } if(((((( cf==1  && (input == 10)) && a668543261 <=  -85) && a1350544514 == 33) && (a297777914 <=  10 && ((a1281480214 == 33 && a363377125 == 6) && a635095050 == 4))) && a1323714376 <= -46)) {
    	cf = 0;
    	a11629652 = 36 ;
    	a1178609647 = (a363377125 + 5); 
    	 printf("");//printf("%d\n", 16); fflush(stdout); 
    } if(((a470024258 == 8 && (a458716067 <=  -81 && a297777914 <=  10)) && (((( cf==1  && (input == 6)) && a1425079908 == 1) && a668543261 <=  -85) && a1281480214 == 33))) {
    	cf = 0;
    	a558123585 = (((((a558123585 * a458716067) % 14999) + -7658) * 1) / 5);
    	a281306570 = (a1425079908 * a635095050);
    	a462100686 = ((a1304128308 + a1178609647) - 8); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm120(int input) {
    if(((a297777914 <=  10 && a668543261 <=  -85) && (a363377125 == 6 && ((a1809397514 == 33 && (( cf==1  && (input == 9)) && a631351130 == 33)) && a1350544514 == 33)))) {
    	
    	        if((a240070971 + 20) > a240070971)
        {
        a240070971 +=  2;
        }
        else
        {
        a240070971 +=  0;
        }	
    	
    	        if((a1019899841 + 20) > a1019899841)
        {
        a1019899841 +=  3;
        }
        else
        {
        a1019899841 +=  0;
        }	
    	cf = 0;
    	a11629652 = 33 ;
    	a1178609647 = (a363377125 + 5); 
    	 printf("");//printf("%d\n", 26); fflush(stdout); 
    } if(((a470024258 == 8 && ((a1350544514 == 33 && ( cf==1  && (input == 3))) && a635095050 == 4)) && ((a668543261 <=  -85 && a458716067 <=  -81) && a1425079908 == 1))) {
    	
    	        if((a1019899841 + 20) > a1019899841)
        {
        a1019899841 +=  1;
        }
        else
        {
        a1019899841 +=  0;
        }	
    	cf = 0;
    	a1281480214 = 32 ;
    	a533054965 = (((((((a458716067 * a458716067) % 14999) % 49) - 129) - 4867) / 5) - -903);
    	a668543261 = ((((((a668543261 * a533054965) % 14999) / 5) % 96) + -51) - -65);
    	a1350544514 = 32 ;
    	a914727600 = ((a470024258 - a470024258) - -9);
    	a1524975081 = (a1304128308 + -3);
    	a1809397514 = 32 ;
    	a631351130 = 32 ;
    	a635095050 = (a363377125 + -1);
    	a363377125 = (a1425079908 - -6);
    	a558123585 = ((((((a558123585 * a297777914) % 14999) + 7977) / 5) % 32) - -45);
    	a1425079908 = ((a470024258 * a1178609647) + -54);
    	a297777914 = ((((((a533054965 * a533054965) * 1) % 71) - -36) + 28998) + -29004);
    	a470024258 = ((a635095050 - a1524975081) + 11); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm21(int input) {
    if(((a1350544514 == 33 && (a458716067 <=  -81 && ((a1304128308 == 9 &&  cf==1 ) && a1281480214 == 33))) && ((a635095050 == 4 && a470024258 == 8) && a1809397514 == 33))) {
    	calculate_outputm119(input);
    } 
    if(((a363377125 == 6 && ((a1304128308 == 10 &&  cf==1 ) && a631351130 == 33)) && (a1281480214 == 33 && (a470024258 == 8 && (a668543261 <=  -85 && a458716067 <=  -81))))) {
    	calculate_outputm120(input);
    } 
}
 void calculate_outputm123(int input) {
    if(((a533054965 <=  -173 && (a1425079908 == 1 && (a470024258 == 8 && a635095050 == 4))) && ((((input == 6) &&  cf==1 ) && a1809397514 == 33) && a458716067 <=  -81))) {
    	cf = 0;
    	a1304128308 = ((a1425079908 * a470024258) - -1);
    	a1178609647 = (a363377125 + 1); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } if(((((a1425079908 == 1 && (( cf==1  && (input == 1)) && a533054965 <=  -173)) && a1281480214 == 33) && a668543261 <=  -85) && (a1350544514 == 33 && a635095050 == 4))) {
    	
    	        if((a706425043 + 20) > a706425043)
        {
        a706425043 +=  3;
        }
        else
        {
        a706425043 +=  0;
        }	
    	cf = 0;
    	a1524975081 = (a363377125 + 4);
    	a533054965 = (((((((a533054965 * a668543261) % 14999) - -13579) / 5) * 5) % 49) + -141);
    	a668543261 = ((((((a533054965 * a533054965) + 167) - 35192) / 5) % 96) + 95);
    	a470024258 = (a1178609647 - -1);
    	a558123585 = ((((((((a558123585 * a623007887) % 14999) % 32) + 44) * 5) + -23217) % 32) - -44);
    	a363377125 = ((a1524975081 / a1524975081) - -6);
    	a1281480214 = 32 ;
    	a1425079908 = (a635095050 + -2);
    	a1350544514 = 32 ;
    	a754697839 = (a1178609647 - -2);
    	a297777914 = (((((((a297777914 * a458716067) % 14999) % 71) - -82) + 26957) * 1) - 26957);
    	a635095050 = (a1524975081 - 5); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm22(int input) {
    if(((a1425079908 == 1 && ((( cf==1  && a623007887 <=  42) && a363377125 == 6) && a297777914 <=  10)) && (a470024258 == 8 && (a458716067 <=  -81 && a533054965 <=  -173)))) {
    	calculate_outputm123(input);
    } 
}
 void calculate_outputm127(int input) {
    if(((( cf==1  && (input == 7)) && a1350544514 == 33) && ((a1281480214 == 33 && (a363377125 == 6 && (a533054965 <=  -173 && a1809397514 == 33))) && a1425079908 == 1))) {
    	cf = 0;
    	a623007887 = ((((((a297777914 * a558123585) % 14999) - 11523) - -10153) / 5) + -14756);
    	a1178609647 = (a914727600 + 5);
    	a458716067 = (((((a558123585 * a533054965) % 14999) + -13418) + 41429) + -28484); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } if(((a668543261 <=  -85 && (((input == 10) &&  cf==1 ) && a297777914 <=  10)) && (((a635095050 == 4 && a1281480214 == 33) && a1425079908 == 1) && a631351130 == 33))) {
    	
    	        if((a188376983 + 20) > a188376983)
        {
        a188376983 +=  1;
        }
        else
        {
        a188376983 +=  0;
        }	
    	cf = 0;
    	a1014630870 = (a914727600 - -9);
    	a470024258 = (a363377125 - -4);
    	a2062265878 = ((((((a297777914 * a668543261) % 14999) + 12772) % 48) + 325) + 0);
    	a1350544514 = 34 ;
    	a363377125 = (a1178609647 - 1);
    	a1425079908 = (a1014630870 + -9);
    	a631351130 = 34 ;
    	a558123585 = (((((((a558123585 * a533054965) % 14999) % 90) - -169) - -1) / 5) - -135);
    	a533054965 = ((((((((a558123585 * a458716067) % 14999) % 101) - -29) * 5) - -19042) % 101) - -9);
    	a297777914 = ((((((a297777914 * a558123585) % 14999) % 109) - -262) + 1) - 1);
    	a1809397514 = 34 ;
    	a635095050 = (a914727600 - -3); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm23(int input) {
    if(((a631351130 == 33 && (a533054965 <=  -173 && (a635095050 == 4 && a668543261 <=  -85))) && (a1281480214 == 33 && (a297777914 <=  10 && (a914727600 == 3 &&  cf==1 ))))) {
    	calculate_outputm127(input);
    } 
}
 void calculate_outputm138(int input) {
    if(((a668543261 <=  -85 && (a635095050 == 4 && a363377125 == 6)) && (a297777914 <=  10 && (a1425079908 == 1 && (( cf==1  && (input == 9)) && a458716067 <=  -81))))) {
    	cf = 0;
    	a631351130 = 34 ;
    	a1350544514 = 34 ;
    	a533054965 = (((((((a533054965 * a458716067) % 14999) % 101) + 11) / 5) - -12905) + -12806);
    	a1425079908 = (a470024258 + -5);
    	a1281480214 = 34 ;
    	a558123585 = (((((((a558123585 * a297777914) % 14999) % 90) + 169) + -2) - 10557) - -10558);
    	a363377125 = (a1425079908 - -5);
    	a2062265878 = (((((a558123585 * a558123585) % 14999) - 21541) - 2313) * 1);
    	a702083417 = a1178609647;
    	a297777914 = (((((((a297777914 * a458716067) % 14999) + 11925) % 109) + 262) - 26255) + 26255);
    	a470024258 = 10;
    	a1809397514 = 34 ;
    	a635095050 = (a363377125 + -2);
    	a458716067 = ((((((a458716067 * a668543261) % 14999) % 99) - -52) - 6434) - -6457);
    	a668543261 = (((((((a668543261 * a533054965) % 14999) % 15) + 124) + -19269) / 5) - -3942); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } if(((a533054965 <=  -173 && (a458716067 <=  -81 && a363377125 == 6)) && (a1281480214 == 33 && (a470024258 == 8 && (((input == 6) &&  cf==1 ) && a635095050 == 4))))) {
    	cf = 0;
    	a2062265878 = ((((((((a558123585 * a458716067) % 14999) % 48) + 326) * 5) + -4229) % 48) - -333);
    	a1014630870 = (a635095050 - -5);
    	a1425079908 = ((a1178609647 - a1178609647) + 3);
    	a533054965 = (((((((a533054965 * a458716067) % 14999) % 101) - -17) * 10) / 9) / 5);
    	a558123585 = ((((((((a558123585 * a2062265878) % 14999) / 5) % 90) + 87) * 5) % 90) + 140);
    	a470024258 = ((a635095050 - a1014630870) - -15);
    	a297777914 = ((((((a297777914 * a2062265878) % 14999) % 109) + 263) / 5) + 201);
    	a363377125 = ((a470024258 / a1425079908) + 5);
    	a631351130 = 34 ;
    	a1809397514 = 34 ;
    	a1350544514 = 34 ;
    	a458716067 = ((((((a458716067 * a297777914) % 14999) % 99) - -96) + 0) / 5);
    	a668543261 = ((((((((a668543261 * a2062265878) % 14999) % 15) - -124) - -8086) * 3) % 15) - -114); 
    	 printf("");//printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm25(int input) {
    if(((a458716067 <=  -81 && ((a1350544514 == 33 && ((a11629652 == 33 &&  cf==1 ) && a363377125 == 6)) && a1809397514 == 33)) && (a631351130 == 33 && a297777914 <=  10))) {
    	calculate_outputm138(input);
    } 
}
 void calculate_outputm143(int input) {
    if(((a1350544514 == 33 && (a1809397514 == 33 && a458716067 <=  -81)) && (a1281480214 == 33 && ((((input == 4) &&  cf==1 ) && a297777914 <=  10) && a635095050 == 4)))) {
    	
    	        if((a1406068516 + 20) > a1406068516)
        {
        a1406068516 += 1;
        }
        else
        {
        a1406068516 += 0;
        }	
    	
    	        if((a188376983 + 20) > a188376983)
        {
        a188376983 +=  4;
        }
        else
        {
        a188376983 +=  0;
        }	
    	cf = 0;
    	a1809397514 = 32 ;
    	a914727600 = a470024258;
    	a363377125 = (a470024258 + -1);
    	a1524975081 = (a635095050 - -5);
    	a635095050 = ((a363377125 / a363377125) - -4);
    	a631351130 = 32 ;
    	a558123585 = ((((((a558123585 * a533054965) % 14999) % 32) - -45) - -1) + -2);
    	a1425079908 = (a1178609647 - 10);
    	a1281480214 = 32 ;
    	a533054965 = ((((((a458716067 * a297777914) % 14999) / 5) % 49) + -123) + -1);
    	a668543261 = ((((((a668543261 * a458716067) % 14999) / 5) % 96) + 6) - -1);
    	a297777914 = ((((((a297777914 * a533054965) % 14999) + 13053) - -842) % 71) - -81);
    	a1350544514 = 32 ;
    	a470024258 = (a1425079908 - -7);
    	a458716067 = ((((((a458716067 * a137310972) % 14999) % 38) - 72) - -2853) - 2857); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } if((((a533054965 <=  -173 && ((a668543261 <=  -85 && (a363377125 == 6 && a470024258 == 8)) && a297777914 <=  10)) && a458716067 <=  -81) && ((input == 5) &&  cf==1 ))) {
    	
    	        if((a1958569006 + 20) > a1958569006)
        {
        a1958569006 +=  2;
        }
        else
        {
        a1958569006 +=  0;
        }	
    	cf = 0;
    	a558123585 = (((((a558123585 * a668543261) % 14999) + -8669) / 5) * 5);
    	a493087397 = ((((((a137310972 * a558123585) % 14999) * 2) % 59) + 62) + 2);
    	a281306570 = (a363377125 + -5); 
    	 printf("");//printf("%d\n", 23); fflush(stdout); 
    } if(((a631351130 == 33 && ((a470024258 == 8 && ((input == 7) &&  cf==1 )) && a458716067 <=  -81)) && (a363377125 == 6 && (a668543261 <=  -85 && a297777914 <=  10)))) {
    	cf = 0;
    	a668543261 = (((((((a137310972 * a137310972) % 14999) % 96) - 39) - 22318) - 4924) - -27266);
    	a363377125 = ((a635095050 / a635095050) + 6);
    	a1524975081 = (a635095050 - -8);
    	a470024258 = (a363377125 - -2);
    	a297777914 = (((((a668543261 * a668543261) % 71) + 81) / 5) - -91);
    	a1281480214 = 32 ;
    	a558123585 = (((((((a558123585 * a533054965) % 14999) % 32) - -45) - 27025) - -50740) + -23714);
    	a1350544514 = 32 ;
    	a1809397514 = 32 ;
    	a458716067 = (((((((a458716067 * a297777914) % 14999) % 38) - 40) - -3830) + -26453) - -22621);
    	a387693620 = (a1524975081 * a1425079908);
    	a631351130 = 32 ;
    	a533054965 = ((((((a137310972 * a668543261) % 14999) * 2) * 1) % 49) - 123);
    	a1425079908 = ((a1178609647 - a363377125) - 3);
    	a635095050 = (a470024258 - 4); 
    	 printf("");//printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm144(int input) {
    if(((a297777914 <=  10 && ((a470024258 == 8 && a458716067 <=  -81) && a668543261 <=  -85)) && ((( cf==1  && (input == 2)) && a635095050 == 4) && a1281480214 == 33))) {
    	cf = 0;
    	 
    	 printf("");//printf("%d\n", 26); fflush(stdout); 
    } if(((((a635095050 == 4 && a458716067 <=  -81) && a470024258 == 8) && a631351130 == 33) && ((( cf==1  && (input == 5)) && a1350544514 == 33) && a363377125 == 6))) {
    	cf = 0;
    	a470024258 = (a1425079908 + 8);
    	a297777914 = ((((3 * 5) + 8720) / 5) + -1715);
    	a363377125 = (a1178609647 - 5);
    	a1304128308 = ((a1425079908 - a1425079908) - -10);
    	a1809397514 = 32 ;
    	a1524975081 = ((a635095050 / a1304128308) - -13);
    	a1350544514 = 32 ;
    	a668543261 = (((((((a668543261 * a137310972) % 14999) % 96) - -13) + -1) - 16779) + 16779);
    	a458716067 = ((((((((a458716067 * a533054965) % 14999) % 38) - 68) * 5) * 5) % 38) + -11);
    	a631351130 = 32 ;
    	a558123585 = (((((((a558123585 * a533054965) % 14999) % 32) - -44) * 5) % 32) - -27);
    	a635095050 = (a363377125 - 2);
    	a1281480214 = 32 ;
    	a533054965 = ((((((a533054965 * a297777914) % 14999) + 16733) * 1) % 49) + -138);
    	a1425079908 = (a363377125 - 5); 
    	 printf("");//printf("%d\n", 20); fflush(stdout); 
    } if(((((a631351130 == 33 && a1350544514 == 33) && a458716067 <=  -81) && (((a1809397514 == 33 && ( cf==1  && (input == 4))) && a533054965 <=  -173) && a470024258 == 8)) && a2114497607 == -3)) {
    	cf = 0;
    	a558123585 = ((((((a558123585 * a668543261) % 14999) + 28769) - 34539) + 11245) + -12192);
    	a281306570 = (a470024258 + -4);
    	a462100686 = (a470024258 + 2); 
    	 printf("");//printf("%d\n", 16); fflush(stdout); 
    } if(((a533054965 <=  -173 && ((a668543261 <=  -85 && ((input == 8) &&  cf==1 )) && a470024258 == 8)) && ((a1809397514 == 33 && a458716067 <=  -81) && a363377125 == 6))) {
    	
    	        if((a2061130608 - 20) < a2061130608)
        {
        a2061130608 -=  2;
        }
        else
        {
        a2061130608 -=  0;
        }	
    	cf = 0;
    	a1178609647 = (a470024258 + 5);
    	a493087397 = (((((((a533054965 * a533054965) % 14999) - 5792) - -20098) * 1) % 91) - -138); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm26(int input) {
    if(((((a137310972 <=  -156 &&  cf==1 ) && a363377125 == 6) && a1350544514 == 33) && (a668543261 <=  -85 && ((a1809397514 == 33 && a1281480214 == 33) && a297777914 <=  10)))) {
    	calculate_outputm143(input);
    } 
    if(((a458716067 <=  -81 && a1425079908 == 1) && ((a1350544514 == 33 && (((((-8 < a137310972) && (158 >= a137310972)) &&  cf==1 ) && a668543261 <=  -85) && a1281480214 == 33)) && a533054965 <=  -173))) {
    	calculate_outputm144(input);
    } 
}
 void calculate_outputm152(int input) {
    if(((((a363377125 == 6 && (a458716067 <=  -81 && (a668543261 <=  -85 && ( cf==1  && (input == 9))))) && a297777914 <=  10) && a1350544514 == 33) && a1281480214 == 33)) {
    	
    	        if((a130136624 + 20) > a130136624)
        {
        a130136624 +=  2;
        }
        else
        {
        a130136624 +=  0;
        }	
    	
    	        if((a1079276458 - 20) < a1079276458)
        {
        a1079276458 -=  4;
        }
        else
        {
        a1079276458 -=  0;
        }	
    	
    	        if((a2114497607 - 20) < a2114497607)
        {
        a2114497607 -=  6;
        }
        else
        {
        a2114497607 -=  0;
        }	
    	
    	        if((a943871142 + 20) > a943871142)
        {
        a943871142 +=  2;
        }
        else
        {
        a943871142 +=  0;
        }	
    	
    	        if((a706425043 - 20) < a706425043)
        {
        a706425043 -=  4;
        }
        else
        {
        a706425043 -=  0;
        }	
    	cf = 0;
    	a914727600 = ((a1425079908 + a281306570) - -3);
    	a533054965 = ((((((a533054965 * a458716067) % 14999) % 49) - 169) - -17030) - 16983);
    	a1524975081 = ((a470024258 / a281306570) - -7);
    	a470024258 = ((a914727600 + a914727600) - 7);
    	a558123585 = ((((((a558123585 * a297777914) % 14999) / 5) % 32) + 44) * 1);
    	a1350544514 = 32 ;
    	a635095050 = (a914727600 + -3);
    	a1425079908 = (a914727600 + -6);
    	a1809397514 = 32 ;
    	a631351130 = 32 ;
    	a297777914 = (((((((a297777914 * a458716067) % 14999) % 71) - -81) * 5) % 71) + 12);
    	a458716067 = (((((((a458716067 * a668543261) % 14999) % 38) + -68) / 5) + -6265) + 6230);
    	a363377125 = ((a1178609647 / a914727600) - -6);
    	a1281480214 = 32 ;
    	a668543261 = (((((((a668543261 * a533054965) % 14999) % 96) - 66) - 27910) / 5) + 5621); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } if(((((((a470024258 == 8 && a1350544514 == 33) && a1281480214 == 33) && a533054965 <=  -173) && a631351130 == 33) && (a1809397514 == 33 && ( cf==1  && (input == 4)))) && a706425043 <= -96)) {
    	cf = 0;
    	a61424176 = (a281306570 - -9);
    	a1178609647 = ((a61424176 + a281306570) + -7); 
    	 printf("");//printf("%d\n", 19); fflush(stdout); 
    } if(((((a635095050 == 4 && (a668543261 <=  -85 && a297777914 <=  10)) && a1281480214 == 33) && a1425079908 == 1) && (((input == 2) &&  cf==1 ) && a470024258 == 8))) {
    	cf = 0;
    	a1524975081 = ((a635095050 * a1425079908) - -5);
    	a914727600 = ((a1524975081 * a470024258) + -63);
    	a1350544514 = 32 ;
    	a1425079908 = ((a1178609647 / a1178609647) - -1);
    	a635095050 = (a1178609647 + -9);
    	a558123585 = ((((((((a558123585 * a668543261) % 14999) - -24604) % 32) + 43) * 5) % 32) + 36);
    	a668543261 = (((((((a533054965 * a533054965) % 14999) + -13938) % 96) - -12) + -4346) + 4346);
    	a363377125 = ((a1178609647 - a281306570) + -3);
    	a297777914 = ((((((a297777914 * a458716067) % 14999) - -4702) % 71) - -82) - -1);
    	a631351130 = 32 ;
    	a1809397514 = 32 ;
    	a533054965 = ((((((a533054965 * a297777914) % 14999) + 16305) % 49) + -164) + -4);
    	a1281480214 = 32 ;
    	a470024258 = ((a1524975081 * a1178609647) + -117); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm154(int input) {
    if(((a297777914 <=  10 && (a631351130 == 33 && ((((input == 1) &&  cf==1 ) && a1809397514 == 33) && a363377125 == 6))) && (a458716067 <=  -81 && a533054965 <=  -173))) {
    	
    	        if((a2061130608 - 20) < a2061130608)
        {
        a2061130608 -=  1;
        }
        else
        {
        a2061130608 -=  0;
        }	
    	
    	        if((a521016673 + 20) > a521016673)
        {
        a521016673 +=  3;
        }
        else
        {
        a521016673 +=  0;
        }	
    	cf = 0;
    	a1178609647 = (a363377125 + 1);
    	a1304128308 = (a1178609647 + 2); 
    	 printf("");//printf("%d\n", 20); fflush(stdout); 
    } if(((a1350544514 == 33 && (((( cf==1  && (input == 7)) && a1809397514 == 33) && a631351130 == 33) && a470024258 == 8)) && (a1425079908 == 1 && a668543261 <=  -85))) {
    	
    	        if((a1471952247 + 20) > a1471952247)
        {
        a1471952247 +=  1;
        }
        else
        {
        a1471952247 +=  0;
        }	
    	cf = 0;
    	a668543261 = (((17 + 68) - -9) - 14);
    	a1524975081 = ((a635095050 / a635095050) - -11);
    	a533054965 = (((((a668543261 * a668543261) % 49) + -122) + -29405) - -29405);
    	a297777914 = (((((((a297777914 * a668543261) % 14999) / 5) - 5007) - 21734) % 71) + 115);
    	a387693620 = (a1425079908 + 11);
    	a1350544514 = 32 ;
    	a1425079908 = (a363377125 + -4);
    	a363377125 = (a281306570 - -1);
    	a558123585 = (((((((a558123585 * a458716067) % 14999) + -11096) - -13662) / 5) % 32) + 45);
    	a458716067 = (((((((a458716067 * a533054965) % 14999) % 38) + -73) * 5) % 38) - 36);
    	a631351130 = 32 ;
    	a1809397514 = 32 ;
    	a635095050 = (a1178609647 - 9);
    	a1281480214 = 32 ;
    	a470024258 = (a1178609647 - 5); 
    	 printf("");//printf("%d\n", 25); fflush(stdout); 
    } if((((a1809397514 == 33 && (a631351130 == 33 && (a470024258 == 8 && ((input == 5) &&  cf==1 )))) && ((a533054965 <=  -173 && a668543261 <=  -85) && a635095050 == 4)) && a1647447633 == 2)) {
    	
    	        if((a1958569006 - 20) < a1958569006)
        {
        a1958569006 -=  2;
        }
        else
        {
        a1958569006 -=  0;
        }	
    	
    	        if((a1471952247 - 20) < a1471952247)
        {
        a1471952247 -=  3;
        }
        else
        {
        a1471952247 -=  0;
        }	
    	cf = 0;
    	a1178609647 = ((a470024258 - a470024258) + 7);
    	a1304128308 = ((a363377125 + a1425079908) + 6); 
    	 printf("");//printf("%d\n", 24); fflush(stdout); 
    } if(((((((input == 10) &&  cf==1 ) && a533054965 <=  -173) && a1281480214 == 33) && (((a635095050 == 4 && a470024258 == 8) && a1809397514 == 33) && a1350544514 == 33)) && a333446562 == -8)) {
    	cf = 0;
    	a558123585 = ((((((a558123585 * a533054965) % 14999) - 12227) * 1) % 32) + 54);
    	a1524975081 = (a470024258 + -1);
    	a914727600 = ((a1524975081 / a635095050) - -5); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } if(((((a363377125 == 6 && a1425079908 == 1) && a1281480214 == 33) && (a458716067 <=  -81 && (a297777914 <=  10 && (a470024258 == 8 && ((input == 6) &&  cf==1 ))))) && a1783572941 == 10)) {
    	cf = 0;
    	a2062265878 = (((((((a533054965 * a297777914) % 14999) * 2) / 5) * 5) % 14812) + 15187);
    	a631219524 = (a635095050 - -7);
    	a558123585 = (((((((a558123585 * a2062265878) % 14999) + -24632) % 90) + 253) + -25320) - -25279); 
    	 printf("");//printf("%d\n", 26); fflush(stdout); 
    } if((((a363377125 == 6 && a458716067 <=  -81) && (a470024258 == 8 && (a1425079908 == 1 && ((((input == 8) &&  cf==1 ) && a668543261 <=  -85) && a635095050 == 4)))) && a1717797827 == 0)) {
    	cf = 0;
    	a224147222 = (((((((a458716067 * a458716067) % 14999) - -14607) - -20) / 5) % 78) + 269);
    	a558123585 = ((((((a558123585 * a533054965) % 14999) - -26050) + -34542) * 10) / 9);
    	a281306570 = ((a1178609647 * a363377125) + -82); 
    	 printf("");//printf("%d\n", 25); fflush(stdout); 
    } if(((((a1809397514 == 33 && (a1425079908 == 1 && (((input == 4) &&  cf==1 ) && a1350544514 == 33))) && a533054965 <=  -173) && (a470024258 == 8 && a635095050 == 4)) && a130136624 == 3)) {
    	
    	        if((a1958569006 + 20) > a1958569006)
        {
        a1958569006 +=  3;
        }
        else
        {
        a1958569006 +=  0;
        }	
    	cf = 0;
    	a1304128308 = (a635095050 + 7);
    	a1178609647 = (a1425079908 - -6); 
    	 printf("");//printf("%d\n", 18); fflush(stdout); 
    } if(((((a1281480214 == 33 && a297777914 <=  10) && a668543261 <=  -85) && a1809397514 == 33) && ((((input == 3) &&  cf==1 ) && a533054965 <=  -173) && a631351130 == 33))) {
    	cf = 0;
    	a281306570 = (a470024258 + -3);
    	a1034097962 = 34 ;
    	a558123585 = ((((((a558123585 * a458716067) % 14999) + -11887) - -7971) * 10) / 9); 
    	 printf("");//printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm155(int input) {
    if((((a458716067 <=  -81 && (a297777914 <=  10 && (((input == 6) &&  cf==1 ) && a635095050 == 4))) && a1425079908 == 1) && (a1350544514 == 33 && a363377125 == 6))) {
    	cf = 0;
    	a558123585 = (((((a558123585 * a458716067) % 14999) - -19000) + -31166) * 1);
    	a542521680 = 32 ;
    	a281306570 = (a1425079908 - -2); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } if((((a1809397514 == 33 && ((a631351130 == 33 && a297777914 <=  10) && a470024258 == 8)) && (a458716067 <=  -81 && (((input == 4) &&  cf==1 ) && a668543261 <=  -85))) && a240070971 == 11)) {
    	
    	        if((a2061130608 - 20) < a2061130608)
        {
        a2061130608 -=  2;
        }
        else
        {
       a2061130608 -=  0;
        }	
    	
    	        if((a1019899841 + 20) > a1019899841)
        {
        a1019899841 +=  4;
        }
        else
        {
        a1019899841 +=  0;
        }	
    	cf = 0;
    	a230802418 = 33 ;
    	a558123585 = ((((((a558123585 * a668543261) % 14999) - 14522) * 1) + 40517) - 35292);
    	a281306570 = (a363377125 + 1); 
    	 printf("");//printf("%d\n", 22); fflush(stdout); 
    } if((((a297777914 <=  10 && a631351130 == 33) && a1350544514 == 33) && (a363377125 == 6 && (a533054965 <=  -173 && (a1425079908 == 1 && ((input == 3) &&  cf==1 )))))) {
    	cf = 0;
    	a61424176 = (a635095050 - -3);
    	a1178609647 = (a1425079908 - -9); 
    	 printf("");//printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm28(int input) {
    if(((a458716067 <=  -81 && (a281306570 == 4 &&  cf==1 )) && ((((a297777914 <=  10 && a533054965 <=  -173) && a1809397514 == 33) && a1350544514 == 33) && a635095050 == 4))) {
    	calculate_outputm152(input);
    } 
    if((((a635095050 == 4 && (a281306570 == 6 &&  cf==1 )) && a1350544514 == 33) && (a1425079908 == 1 && ((a458716067 <=  -81 && a297777914 <=  10) && a631351130 == 33)))) {
    	calculate_outputm154(input);
    } 
    if(((((a363377125 == 6 && a635095050 == 4) && a668543261 <=  -85) && a458716067 <=  -81) && (a470024258 == 8 && (a1281480214 == 33 && ( cf==1  && a281306570 == 8))))) {
    	calculate_outputm155(input);
    } 
}

 void calculate_output(int input) {
        cf = 1;

    if(((a363377125 == 6 && (a668543261 <=  -85 && ( cf==1  && a558123585 <=  12))) && (a533054965 <=  -173 && ((a1281480214 == 33 && a1425079908 == 1) && a470024258 == 8)))) {
    	if(((((a533054965 <=  -173 && a1809397514 == 33) && a363377125 == 6) && a297777914 <=  10) && (((a281306570 == 1 &&  cf==1 ) && a1281480214 == 33) && a668543261 <=  -85))) {
    		calculate_outputm1(input);
    	} 
    	if(((a470024258 == 8 && ((a297777914 <=  10 && a1350544514 == 33) && a1425079908 == 1)) && (a363377125 == 6 && (a668543261 <=  -85 && ( cf==1  && a281306570 == 2))))) {
    		calculate_outputm2(input);
    	} 
    	if((((a1350544514 == 33 && (a281306570 == 3 &&  cf==1 )) && a668543261 <=  -85) && (a533054965 <=  -173 && ((a470024258 == 8 && a363377125 == 6) && a1425079908 == 1)))) {
    		calculate_outputm3(input);
    	} 
    	if((((a668543261 <=  -85 && (a297777914 <=  10 && ( cf==1  && a281306570 == 4))) && a1809397514 == 33) && (a635095050 == 4 && (a470024258 == 8 && a1425079908 == 1)))) {
    		calculate_outputm4(input);
    	} 
    	if((((a1281480214 == 33 && ((a297777914 <=  10 && a631351130 == 33) && a470024258 == 8)) && a1425079908 == 1) && (a668543261 <=  -85 && (a281306570 == 6 &&  cf==1 )))) {
    		calculate_outputm6(input);
    	} 
    } 
    if((((((((12 < a558123585) && (77 >= a558123585)) &&  cf==1 ) && a1425079908 == 2) && a1281480214 == 32) && ((-85 < a668543261) && (109 >= a668543261))) && ((a470024258 == 9 && a363377125 == 7) && ((-173 < a533054965) && (-73 >= a533054965))))) {
    	if((((a1425079908 == 2 && ((a1524975081 == 7 &&  cf==1 ) && a363377125 == 7)) && a631351130 == 32) && ((((-173 < a533054965) && (-73 >= a533054965)) && a1281480214 == 32) && a1809397514 == 32))) {
    		calculate_outputm9(input);
    	} 
    	if(((((a1524975081 == 8 &&  cf==1 ) && a1425079908 == 2) && ((-85 < a668543261) && (109 >= a668543261))) && (a363377125 == 7 && ((((10 < a297777914) && (153 >= a297777914)) && ((-81 < a458716067) && (-3 >= a458716067))) && a1281480214 == 32)))) {
    		calculate_outputm10(input);
    	} 
    	if((((a363377125 == 7 && (((-85 < a668543261) && (109 >= a668543261)) && ( cf==1  && a1524975081 == 9))) && ((-173 < a533054965) && (-73 >= a533054965))) && ((a470024258 == 9 && a1425079908 == 2) && a1809397514 == 32))) {
    		calculate_outputm11(input);
    	} 
    	if(((a1425079908 == 2 && ((-85 < a668543261) && (109 >= a668543261))) && (a635095050 == 5 && (a1350544514 == 32 && (((a1524975081 == 10 &&  cf==1 ) && a363377125 == 7) && ((10 < a297777914) && (153 >= a297777914))))))) {
    		calculate_outputm12(input);
    	} 
    	if((((a470024258 == 9 && ( cf==1  && a1524975081 == 12)) && ((10 < a297777914) && (153 >= a297777914))) && (a635095050 == 5 && (a1425079908 == 2 && (a1350544514 == 32 && ((-81 < a458716067) && (-3 >= a458716067))))))) {
    		calculate_outputm14(input);
    	} 
    	if((((a1524975081 == 13 &&  cf==1 ) && a363377125 == 7) && (((a1425079908 == 2 && (a631351130 == 32 && a1281480214 == 32)) && a635095050 == 5) && a470024258 == 9))) {
    		calculate_outputm15(input);
    	} 
    } 
    if(((a1350544514 == 34 && ((153 < a297777914) && (372 >= a297777914))) && (a1809397514 == 34 && (a631351130 == 34 && ((a363377125 == 8 && (((77 < a558123585) && (259 >= a558123585)) &&  cf==1 )) && ((-3 < a458716067) && (197 >= a458716067))))))) {
    	if(((a635095050 == 6 && ((a2062265878 <=  130 &&  cf==1 ) && ((109 < a668543261) && (140 >= a668543261)))) && (((((153 < a297777914) && (372 >= a297777914)) && a631351130 == 34) && ((-3 < a458716067) && (197 >= a458716067))) && ((-73 < a533054965) && (130 >= a533054965))))) {
    		calculate_outputm17(input);
    	} 
    	if(((((130 < a2062265878) && (277 >= a2062265878)) &&  cf==1 ) && (a1281480214 == 34 && ((((-73 < a533054965) && (130 >= a533054965)) && ((a1350544514 == 34 && a363377125 == 8) && ((109 < a668543261) && (140 >= a668543261)))) && a1425079908 == 3)))) {
    		calculate_outputm18(input);
    	} 
    } 
    if(((((a1809397514 == 33 && a1281480214 == 33) && a631351130 == 33) && a363377125 == 6) && ((( cf==1  && 259 < a558123585) && a635095050 == 4) && a533054965 <=  -173))) {
    	if(((a1281480214 == 33 && ( cf==1  && a1178609647 == 7)) && ((((a1350544514 == 33 && a458716067 <=  -81) && a363377125 == 6) && a631351130 == 33) && a1809397514 == 33))) {
    		calculate_outputm21(input);
    	} 
    	if((((((a1809397514 == 33 && ( cf==1  && a1178609647 == 8)) && a1350544514 == 33) && a1281480214 == 33) && a470024258 == 8) && (a458716067 <=  -81 && a297777914 <=  10))) {
    		calculate_outputm22(input);
    	} 
    	if((((a668543261 <=  -85 && (a470024258 == 8 && a363377125 == 6)) && a1281480214 == 33) && (a1425079908 == 1 && (( cf==1  && a1178609647 == 9) && a1809397514 == 33)))) {
    		calculate_outputm23(input);
    	} 
    	if(((a1281480214 == 33 && (a635095050 == 4 && (a533054965 <=  -173 && ((a1178609647 == 11 &&  cf==1 ) && a1809397514 == 33)))) && (a631351130 == 33 && a1350544514 == 33))) {
    		calculate_outputm25(input);
    	} 
    	if(((((a1178609647 == 12 &&  cf==1 ) && a635095050 == 4) && a363377125 == 6) && (a458716067 <=  -81 && (a668543261 <=  -85 && (a1350544514 == 33 && a1809397514 == 33))))) {
    		calculate_outputm26(input);
    	} 
    	if((((a458716067 <=  -81 && a1809397514 == 33) && a363377125 == 6) && (a635095050 == 4 && (a631351130 == 33 && (a533054965 <=  -173 && ( cf==1  && a1178609647 == 14)))))) {
    		calculate_outputm28(input);
    	} 
    } 
    errorCheck();

if( cf==1 ) 
    {
    	//fprintf("");//printf(stderr, "Invalid input: %d\n", input); 
} 
}

int input,output;
int main()
{
kappa = 0;
    // main i/o-loop

   int symb;
   for (int FLAG=0;FLAG<BOUND;FLAG++)
    {
    if (fread(&symb, sizeof(int), 1, stdin) != 1) { return 0; }     
        // operate eca engine
        if((symb != 2) && (symb != 9) && (symb != 4) && (symb != 10) && (symb != 5) && (symb != 1) && (symb != 6) && (symb != 8) && (symb != 7) && (symb != 3))
          return -2;
        calculate_output(symb);
    }
}
